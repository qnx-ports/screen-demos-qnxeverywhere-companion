#!/bin/bash
_exe_name=fullscreen-winmgr
_install_dir="$DESTDIR/$PREFIX"
if [[ $1 == install ]]; then
    mkdir -p $_install_dir/bin
    install -v -m755 $_exe_name $_install_dir/bin
    exit
fi

LDFLAGS="$LDFLAGS -lscreen -lsocket $FT2_LIBS $PNG_LIBS"
SRC="$(ls | grep -e .c$ | xargs)"
echo "CFLAGS: $CFLAGS"
echo "LDFLAGS: $LDFLAGS"
echo "SRC: $SRC"

# make sure you set CC
echo "CC: $CFLAGS $SRC $LDFLAGS -o $_exe_name"
$CC $CFLAGS $SRC $LDFLAGS -o $_exe_name
