# fullscreen-winmgr

fullscreen-winmgr is a QNX sample program demonstrating the Screen API for building a window manager. It implements a complete window management system with taskbar, window switching, and application lifecycle management.

## Building Instructions

### Prerequisites

You need to have a local QNX SDP to build this project. To start, get a [QNX 8.0 license](https://www.qnx.com/products/everywhere/) and follow the official instructions to install QNX 8.0 to your host machine.

### Minimum Requirements on QSC
- com.qnx.qnx800.target/0.0.1.00135T202311191043L
- com.qnx.qnx800.host.linux.x86_64/0.0.1.00135T202311191043L
- com.qnx.qnx800.target.screen.fonts.engine/0.0.1.00020T202311191218L
- com.qnx.qnx800.target.screen.img_codecs/0.0.1.00102T202503082205L

### Building Steps

```bash
# Clone repo
git clone https://gitlab.com/qnx/projects/demolauncher.git && cd demolauncher

# Source the QNX environment
source <QNX-DIRECTORY>/qnxsdp-env.sh

# Build for aarch64
make
```

## Usage

### Basic Operation
1. **Start the Window Manager**: Launch the fullscreen-winmgr application
2. **Launch Applications**: Start other Screen applications - they will be automatically managed
3. **Switch Windows**: Use Alt+Tab to open the taskbar and cycle through windows
4. **Close Windows**: Use Alt+Tab+Delete to close the selected window (if the application allows it)

### Application Integration
Applications can optionally specify how they want to be managed by this window manager by calling `screen_manage_window()` or setting the `SCREEN_PROPERTY_USER_DATA` property:

```c
// Example: Using screen_manage_window() to send message to the window manager
screen_manage_window(window, "Frame=Y");

// Example: Using SCREEN_PROPERTY_USER_DATA to send message to the window manager
screen_set_event_property_cv(win_manager_event, SCREEN_PROPERTY_USER_DATA, strlen("can_close=false"), "can_close=false");
```
>**Note** = You can look at the demolauncher code for more details on how this is done.

### Supported Manager Messages
- `Frame=Y/N`: Mark the application as "managed" by the window manager
- `can_close=true/false`: Allow or prevent window closure via Alt+Delete

## Deployment

1. Copy binary to target:
```bash
scp ./nto/aarch64/le/fullscreen-winmgr qnxuser@<target_IP>:~/bin
```

2. Launch the window manager:
```bash
./fullscreen-winmgr
```

3. Launch applications to be managed:
```bash
# Example: Launch applications that will be managed by the window manager
./your-application
```
## Additional Resources

- [QNX Screen Developer's Guide](https://www.qnx.com/developers/docs/8.0/com.qnx.doc.screen/topic/manual/cscreen_about.html)