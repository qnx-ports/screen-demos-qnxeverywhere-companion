/*
 * Copyright (c) 2024, BlackBerry Limited. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <pthread.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/keycodes.h>
#include <screen/screen.h>
#include <unistd.h>

#define MAX_NUM_WINDOWS 8

const int VISIBLE_VALUE = 1;
const int INVISIBLE_VALUE = 0;
const int TASKBAR_BG_COLOR = 0xC0003366;
const int TASKBAR_BG_COLOR_HIGHLIGHT_COLOR = 0xFF99CCFF;

const int Z_ORDER_ACTIVE_WINDOW = 0;
const int Z_ORDER_TASKBAR_BACKGROUND = Z_ORDER_ACTIVE_WINDOW + 1;
const int Z_ORDER_TASKBAR_SELECTED_WIN = Z_ORDER_TASKBAR_BACKGROUND + 1;
const int Z_ORDER_TASKBAR_WIN = Z_ORDER_TASKBAR_BACKGROUND + 1;

const int DEFAULT_WIDTH = 1920;
const int DEFAULT_HEIGHT = 1080;

#define DISPLAY_WIDTH display_size[0]
#define DISPLAY_HEIGHT display_size[1]

// Width and height of taskbar was chosen on a 1080p display; convert them to percentages and when
// used multiply them by the display resolution (to keep same size ratios on different resolutions)
#define TASKBAR_HEIGHT (200.0 / DEFAULT_HEIGHT * DISPLAY_HEIGHT)
#define TASKBAR_PADDING_WITDH (40.0 / DEFAULT_WIDTH * DISPLAY_WIDTH)
#define TASKBAR_PADDING_HEIGHT (40.0 / DEFAULT_HEIGHT * DISPLAY_HEIGHT)
#define TASKBAR_SPACE_BETWEEN_PREVIEW (20.0 / DEFAULT_WIDTH * DISPLAY_WIDTH)
#define HIGHLIGHT_WINDOW_OFFSET_WIDTH (10.0 / DEFAULT_WIDTH * DISPLAY_WIDTH)
#define HIGHLIGHT_WINDOW_OFFSET_HEIGHT (10.0 / DEFAULT_HEIGHT * DISPLAY_HEIGHT)

const int NUM_WINDOWS_PER_PAGE = 5;

typedef struct window {
	screen_window_t handle;
	screen_window_t taskbar_preview;
	bool renders_with_child_windows;
	bool can_be_closed;
	bool is_managed;
	bool is_paused;
} window_t;

screen_context_t screen_ctx;
window_t created_windows[MAX_NUM_WINDOWS];
screen_window_t taskbar_win;
screen_window_t taskbar_highlight_win;

int display_size[2];
int last_window_index;
int selected_window_index;
bool is_demo = false;

#define LOG_ERROR(c) fprintf(stderr, "Error in %s calling %s (line %d): %s\n", __func__, c,  __LINE__, strerror(errno))

int
num_windows()
{
	return last_window_index + 1;
}

/* Size Functions */

void
taskbar_size(int *write_to)
{
	write_to[0] = DISPLAY_WIDTH - TASKBAR_PADDING_WITDH;
	write_to[1] = TASKBAR_HEIGHT;
}

void
preview_size(int *write_to)
{
	int taskbar_size_array[2];
	taskbar_size(taskbar_size_array);

	int display_width_without_padding = taskbar_size_array[0] -
										(NUM_WINDOWS_PER_PAGE + 1) * TASKBAR_SPACE_BETWEEN_PREVIEW; // Padding between taskbar windows

	write_to[0] = display_width_without_padding / NUM_WINDOWS_PER_PAGE;
	write_to[1] = taskbar_size_array[1] - TASKBAR_PADDING_HEIGHT;
}

void
taskbar_highlight_size(int *write_to)
{
	int preview_size_array[2];
	preview_size(preview_size_array);

	write_to[0] = preview_size_array[0] + HIGHLIGHT_WINDOW_OFFSET_WIDTH;
	write_to[1] = preview_size_array[1] + HIGHLIGHT_WINDOW_OFFSET_HEIGHT;
}


/* Position Functions */

void
taskbar_position(int *write_to)
{
	write_to[0] = TASKBAR_PADDING_WITDH / 2;
	write_to[1] = DISPLAY_HEIGHT / 2 - (TASKBAR_HEIGHT/ 2);
}

void
taskbar_highlight_position(int *write_to)
{
	int taskbar_background_pos[2];
	taskbar_position(taskbar_background_pos);

	int taskbar_size_array[2];
	taskbar_size(taskbar_size_array);

	int taskbar_highlight_size_array[2];
	taskbar_highlight_size(taskbar_highlight_size_array);

	int space_vertical = (taskbar_size_array[1] - taskbar_highlight_size_array[1]) / 2;

	write_to[0] = (taskbar_size_array[0] / 2 + taskbar_background_pos[0]) - taskbar_highlight_size_array[0] / 2 - HIGHLIGHT_WINDOW_OFFSET_WIDTH / 2;
	write_to[1] = taskbar_background_pos[1] + space_vertical;
}

void
preview_position(int preview_index, int *write_to)
{
	int window_size[2];
	preview_size(window_size);

	int highlight_win_pos[2];
	taskbar_highlight_position(highlight_win_pos);

	write_to[0] = highlight_win_pos[0] +
				  HIGHLIGHT_WINDOW_OFFSET_WIDTH / 2 +	// Make sure highlight window is visible to left and right of the first taskbar preview
				  preview_index * (window_size[0] + TASKBAR_SPACE_BETWEEN_PREVIEW) + // Skip other windows in the taskbar
				  (preview_index >= NUM_WINDOWS_PER_PAGE) * window_size[0]; // Add an additional offset to ensure only up to NUM_WINDOWS_PER_PAGE windows are visible in taskbar at any time

	write_to[1] = highlight_win_pos[1] + HIGHLIGHT_WINDOW_OFFSET_HEIGHT / 2;
}

//Get process name from /proc/%d/cmdline
void get_process_name(pid_t pid, char *process_name, size_t name_len) {
	char proc_path[256];
	snprintf(proc_path, sizeof(proc_path), "/proc/%d/cmdline", pid);

	// Open the /proc/<pid>/cmdline file
	FILE *fp = fopen(proc_path, "r");
	if (fp) {
		// Read the process name
		if (fgets(process_name, name_len, fp) != NULL) {
			// Remove the trailing newline character if it exists
			size_t len = strlen(process_name);
			if (len > 0 && process_name[len - 1] == '\n') {
				process_name[len - 1] = '\0';
			}
		}
		fclose(fp);
	} else {
		LOG_ERROR("Failed to open process file");
		strncpy(process_name, "Unknown", name_len);
	}
}

// GTK4 is special due to its use of child windows for rendering. Using child windows for rendering is
// not specific to GTK4, eventually this function can be removed one JIRA ID 3010277 is fixed
bool is_window_handle_gtk4(screen_window_t win) {
	int pid;
	if (screen_get_window_property_iv(win, SCREEN_PROPERTY_OWNER_PID, &pid)) {
		LOG_ERROR("screen_get_window_property_iv(SCREEN_PROPERTY_OWNER_PID)");
		return false;
	}

	char process_name[512];
	get_process_name(pid, process_name, sizeof(process_name));

	return strstr(process_name, "gtk4") != NULL;
}

int
init_window(window_t *win, int taskbar_open)
{

	// Create a taskbar preview window - this will be the thumbnail shown in the taskbar
	if(screen_create_window(&win->taskbar_preview, screen_ctx)) {
		LOG_ERROR("screen_create_window");
		return -1;
	}

	// Set the main window's z-order to be the bottom layer (active window layer)
	if(screen_set_window_property_iv(win->handle, SCREEN_PROPERTY_ZORDER, &Z_ORDER_ACTIVE_WINDOW)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_ZORDER)");
		goto fail;
	}

	// Set the main window to full screen size - all windows are fullscreen in this window manager
	if(screen_set_window_property_iv(win->handle, SCREEN_PROPERTY_SIZE, display_size)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
		goto fail;
	}

	// Set the taskbar preview size to 256x256 pixels for the thumbnail
	int taskbar_window_size[2] = {256, 256};
	if(screen_set_window_property_iv(win->taskbar_preview, SCREEN_PROPERTY_SIZE, taskbar_window_size)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
		goto fail;
	}

	// Set the taskbar preview's z-order to appear above the main window when taskbar is open
	if(screen_set_window_property_iv(win->taskbar_preview, SCREEN_PROPERTY_ZORDER, &Z_ORDER_TASKBAR_WIN)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_ZORDER) ");
		goto fail;
	}

	// Set the taskbar preview to be fully opaque (no transparency)
	int transparency = SCREEN_TRANSPARENCY_NONE;
	if(screen_set_window_property_iv(win->taskbar_preview, SCREEN_PROPERTY_TRANSPARENCY, &transparency)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_TRANSPARENCY)");
		goto fail;
	}

	// Set the taskbar preview to be invisible by default - only shows when taskbar opens
	if (screen_set_window_property_iv(win->taskbar_preview, SCREEN_PROPERTY_VISIBLE,  & INVISIBLE_VALUE)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
		goto fail;
	}

	// Set the taskbar preview to not steal focus
	int sensitivity = SCREEN_SENSITIVITY_MASK_NO_FOCUS;
	if (screen_set_window_property_iv(win->taskbar_preview, SCREEN_PROPERTY_SENSITIVITY, &sensitivity)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SENSITIVITY)");
		goto fail;
	}

	// Share rendering buffers between the main window and taskbar preview
	// This enables the preview to show real-time content from the main window.
	// GTK4 is an exception due to its use of child windows for rendering, which doesn't
	// work for sharing window buffers; instead screenshots are taken for those windows
	// See JIRA ID 3010277 as well, in the future screenshot behaviour won't be just for GTK if child windows are used for rendering
	if (!is_window_handle_gtk4(win->handle)) {
		if(screen_share_window_buffers(win->taskbar_preview, win->handle)) {
			LOG_ERROR("screen_share_window_buffers");
			goto fail;
		}
	} else {
		win->renders_with_child_windows = true;

		if (screen_create_window_buffers(win->taskbar_preview, 1)) {
			LOG_ERROR("screen_create_window_buffers");
			goto fail;
		}
	}

	// Apply all the property changes immediately
	if (screen_flush_context(screen_ctx, 0)) {
		LOG_ERROR("screen_flush_context");
		goto fail;
	}

	return 0;

fail:
	// Clean up the taskbar preview window if any step failed
	screen_destroy_window(win->taskbar_preview);

	return -1;
}

int
change_taskbar_visibility(bool is_visible)
{
	int visible_value = is_visible ? VISIBLE_VALUE : INVISIBLE_VALUE;

	// Show/hide all taskbar preview windows (window thumbnails)
	// Loop through all managed windows and update their taskbar preview visibility
	for (int i = 0; i < num_windows(); i++) {
		if (is_visible && created_windows[i].renders_with_child_windows) {
			screen_buffer_t buf;

			// Still show a black window as an absolute worst case in case any of these calls go wrong
			if (screen_get_window_property_pv(created_windows[i].taskbar_preview, SCREEN_PROPERTY_RENDER_BUFFERS, (void**)&buf)) {
				LOG_ERROR("screen_get_window_property_pv(SCREEN_PROPERTY_RENDER_BUFFERS)");
			} else if (screen_read_window(created_windows[i].handle, buf, 0, NULL, 0)) {
				LOG_ERROR("screen_read_window");
			} else if (screen_post_window(created_windows[i].taskbar_preview, buf, 0, NULL, 0)) {
				LOG_ERROR("screen_post_window");
			}
		}

		// Only process windows that have a taskbar preview created
		if (created_windows[i].taskbar_preview && screen_set_window_property_iv(created_windows[i].taskbar_preview, SCREEN_PROPERTY_VISIBLE, &visible_value)) {
			LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
			return -1;
		}
	}

	// Show/hide the taskbar background (dark panel behind the previews)
	if (screen_set_window_property_iv(taskbar_win, SCREEN_PROPERTY_VISIBLE, &visible_value)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
		return -1;
	}

	// Show/hide the taskbar highlight rectangle (blue border around selected window)
	if (screen_set_window_property_iv(taskbar_highlight_win, SCREEN_PROPERTY_VISIBLE, &visible_value)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
		return -1;
	}

	// Apply all visibility changes immediately to ensure taskbar appears/disappears instantly
	if (screen_flush_context(screen_ctx, 0)) {
		LOG_ERROR("screen_flush_context");
		return -1;
	}

	return 0;
}

int
change_new_window_visibility()
{
	// Loop through all windows from index 0 to last_window_index-1 and make them invisible
	for (int i = 0; i < last_window_index; i++) {
		if (screen_set_window_property_iv(created_windows[i].handle, SCREEN_PROPERTY_VISIBLE, &INVISIBLE_VALUE)) {
			LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
			return -1;
		}
		// Set status on all windows index 0 to last_window_index-1 to INVISIBLE
		int status = SCREEN_STATUS_INVISIBLE;
		if (screen_set_window_property_iv(created_windows[i].handle, SCREEN_PROPERTY_STATUS, &status)) {
			LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_STATUS)");
			return -1;
		}
	}

	// Show only the most recent window (the one at last_window_index)
	if (screen_set_window_property_iv(created_windows[last_window_index].handle, SCREEN_PROPERTY_VISIBLE, &VISIBLE_VALUE)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
		return -1;
	}
	// Set status on most recent window to VISIBLE
	int status = SCREEN_STATUS_VISIBLE;
	if (screen_set_window_property_iv(created_windows[last_window_index].handle, SCREEN_PROPERTY_STATUS, &status)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_STATUS)");
		return -1;
	}

	// Apply all visibility changes immediately to ensure instant window switching
	if (screen_flush_context(screen_ctx, 0)) {
		LOG_ERROR("screen_flush_context");
		if (errno != ENOENT) {
			return -1;
		}
	}

	return 0;
}

int
create_taskbar_component(screen_window_t *window, int size[2], int position[2], int colour, int zorder, const char* name)
{
	// Create a new window in the screen context
	if(screen_create_window(window, screen_ctx)) {
		LOG_ERROR("screen_create_window");
		return -1;
	}

	// Set pixel format to RGBA8888
	int format = SCREEN_FORMAT_RGBA8888;
	if(screen_set_window_property_iv(*window, SCREEN_PROPERTY_FORMAT, &format)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_FORMAT)");
		goto fail;
	}

	// Set usage type to NATIVE (required for screen_fill() and screen_blit() operations)
	int usage = SCREEN_USAGE_NATIVE;
	if (screen_set_window_property_iv(*window, SCREEN_PROPERTY_USAGE, &usage)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_USAGE)");
		goto fail;
	}

	// Set the size of the rendering buffer (where pixel data is stored)
	if (screen_set_window_property_iv(*window, SCREEN_PROPERTY_BUFFER_SIZE, size)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_BUFFER_SIZE)");
		goto fail;
	}

	// Create the window buffers with the size of SCREEN_PROPERTY_BUFFER_SIZE as set for the window.
	if (screen_create_window_buffers(*window, 1)) {
		LOG_ERROR("screen_create_window_buffers");
		goto fail;
	}

	// Set the actual display size of the window
	if (screen_set_window_property_iv(*window, SCREEN_PROPERTY_SIZE, size)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
		goto fail;
	}

	// Position the window at the specified [x, y] coordinates
	if (screen_set_window_property_iv(*window, SCREEN_PROPERTY_POSITION, position)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_POSITION)");
		goto fail;
	}

	// Get a handle to the window's rendering buffer for drawing
	screen_buffer_t screen_buf;
	if (screen_get_window_property_pv(*window, SCREEN_PROPERTY_RENDER_BUFFERS, (void **)&screen_buf)) {
		LOG_ERROR("screen_get_window_property_pv(SCREEN_PROPERTY_RENDER_BUFFERS)");
		goto fail;
	}

	// Define a fill operation to color the entire buffer with solid color
	int bg_blit[] = {
		SCREEN_BLIT_COLOR, colour,
		SCREEN_BLIT_END
	};

	// Fill the entire buffer with the specified background color
	if (screen_fill(screen_ctx, screen_buf, bg_blit)) {
		LOG_ERROR("screen_fill() ");
		goto fail;
	}

	// Make the window visible on screen by posting the buffer content
	if (screen_post_window(*window, screen_buf, 0, NULL, 0)) {
		LOG_ERROR("screen_post_window");
		goto fail;
	}

	// Set the z-order
	if(screen_set_window_property_iv(*window, SCREEN_PROPERTY_ZORDER, &zorder)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_ZORDER)");
		goto fail;
	}

	// Make the window initially invisible (hidden until needed)
	if(screen_set_window_property_iv(*window, SCREEN_PROPERTY_VISIBLE, &INVISIBLE_VALUE)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
		goto fail;
	}

	// Set the taskbar preview to not steal focus
	int sensitivity = SCREEN_SENSITIVITY_MASK_NO_FOCUS;
	if (screen_set_window_property_iv(*window, SCREEN_PROPERTY_SENSITIVITY, &sensitivity)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SENSITIVITY)");
		goto fail;
	}

	// Flush the context to ensure all pending operations are completed
	if (screen_flush_context(screen_ctx, 0)) {
		LOG_ERROR("screen_flush_context");
		goto fail;
	}

	return 0;

fail:
	screen_destroy_window(*window);

	return -1;
}

int
organize_taskbar(int selected_index)
{
	int original_selected_index = selected_index;
	selected_index = min((selected_index + NUM_WINDOWS_PER_PAGE / 2), MAX_NUM_WINDOWS - 1);

	// Clear previous taskbar window positions by putting them offscreen
	for (int i = 0; i < MAX_NUM_WINDOWS; i++) {
		if (!created_windows[i].taskbar_preview) {
			continue;
		}

		if(screen_set_window_property_iv(created_windows[i].taskbar_preview, SCREEN_PROPERTY_POSITION, display_size)) {
			LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
			return -1;
		}
	}

	// Position the visible windows in the taskbar (up to NUM_WINDOWS_PER_PAGE = 5)
	for (int i = 0; i < NUM_WINDOWS_PER_PAGE; i++) {
		int taskbar_index_offset = original_selected_index - selected_index;

		// If current taskbar preview is too far away from current taskbar
		// preview (second condition), don't set position to ensure
		// there is no chance of it showing in the taskbar
		if (!created_windows[selected_index].taskbar_preview || (taskbar_index_offset > NUM_WINDOWS_PER_PAGE / 2)) {
			selected_index -= 1;
			if (selected_index == -1) {
				break;
			}

			continue;
		}

		// Get the calculated size for window previews in the taskbar
		int win_size[2];
		preview_size(&win_size[0]);

		// Calculate the position for this window preview based on its offset from center
		int win_pos[2];
		preview_position(taskbar_index_offset, win_pos);

		// Set the position of the window preview in the taskbar
		if(screen_set_window_property_iv(created_windows[selected_index].taskbar_preview, SCREEN_PROPERTY_POSITION, win_pos)) {
			LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_POSITION)");
			return -1;
		}

		// Set the size of the window preview in the taskbar
		if(screen_set_window_property_iv(created_windows[selected_index].taskbar_preview, SCREEN_PROPERTY_SIZE, win_size)) {
			LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
			return -1;
		}

		// Set transparency based on position relative to selected window
		// Windows to the left get 25% opacity, selected and right windows get 100% opacity
		int transparency = selected_index > original_selected_index ? 64 : 255;
		if(screen_set_window_property_iv(created_windows[selected_index].taskbar_preview, SCREEN_PROPERTY_GLOBAL_ALPHA, &transparency)) {
			LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_TRANSPARENCY)");
			return -1;
		}

		// Move to the next iteration
		selected_index -= 1;
		if (selected_index == -1) {
			break;
		}
	}

	// Flush all changes to ensure they take effect immediately
	if (screen_flush_context(screen_ctx, 0)) {
		LOG_ERROR("screen_flush_context");
		return -1;
	}

	return 0;
}

void
shift_window_handles_left(int starting_index)
{
	for(int i = starting_index; i < last_window_index; i++) {
		created_windows[i] = created_windows[i + 1];
	}

	// Remove duplicate pointers to the (previously) last window index's resources
	memset(&created_windows[last_window_index], 0, sizeof(window_t));
}

int get_window_index(screen_window_t window) {
	char target_id[256];
	// Get the unique ID string of the target window for comparison
	if (screen_get_window_property_cv(window, SCREEN_PROPERTY_ID, sizeof(target_id), target_id)) {
		LOG_ERROR("screen_get_window_property_cv(SCREEN_PROPERTY_ID)");
		return -1;
	}

	char window_id[256];
	// Search through all managed windows to find a matching ID
	for (int i = 0; i < num_windows(); i++) {
		// Get the ID of the current managed window
		if (screen_get_window_property_cv(created_windows[i].handle, SCREEN_PROPERTY_ID, sizeof(window_id), window_id)) {
			LOG_ERROR("screen_get_window_property_cv(SCREEN_PROPERTY_ID)");
			return -1;
		}

		// Compare window IDs - if they match, we found the window
		if (strcmp(target_id, window_id) == 0) {
			return i;
		}
	}

	fprintf(stderr, "Index for window handle could not be found\n");
	return -1;
}

int handle_can_close_key(screen_window_t sending_window, bool can_close) {
	int target_index = get_window_index(sending_window);
	if (target_index < 0) {
		return -1;
	}

	created_windows[target_index].can_be_closed = can_close;

	return 0;
}

int handle_managed_key(screen_window_t sending_window, bool managed) {
	int target_index = get_window_index(sending_window);
	if (target_index < 0) {
		return -1;
	}

	created_windows[target_index].is_managed = managed;

	return 0;
}

int process_manager_message(screen_window_t sending_window, char *manager_message) {
	/*
		The type of message expected to change behaviour of window manager from other programs is key=value=key=value ...
		For example:

		screen_event_t win_manager_event;
		screen_display_t current_disp;
		int event_type = SCREEN_EVENT_MANAGER;
		char *manager_message = "can_close:false";

		screen_get_window_property_pv(window, SCREEN_PROPERTY_DISPLAY, (void**)&current_disp);

		screen_create_event(&win_manager_event));
		screen_set_event_property_iv(win_manager_event, SCREEN_PROPERTY_TYPE, &event_type);
		screen_set_event_property_pv(win_manager_event, SCREEN_PROPERTY_WINDOW, (void**)&window);
		screen_set_event_property_cv(win_manager_event, SCREEN_PROPERTY_USER_DATA, strlen(manager_message), manager_message);
		screen_flush_context(context, 0);

		screen_inject_event(current_disp, win_manager_event);

		Note: For the purpose of this demo, there are no restrictions on which apps can disable the window manager's close event
		Note: Look at the demolauncher code for an example of how to send a manager message to this window manager.
	*/

	// Parse the message string, extracting key-value pairs separated by '='
	for(int i = 0;; i++) {
		char *key = strtok(i == 0 ? manager_message : NULL, "=");
		char *value = strtok(NULL, "=");

		if (!key || !value) {
			break;
		}

		// Handle the "can_close" command - controls whether window can be closed by window manager
		if (strcmp(key, "can_close") == 0) {
			if (strcmp(value, "true") == 0) {
				if (handle_can_close_key(sending_window, true)) {
					return -1;
				}
			} else if (strcmp(value, "false") == 0) {
				if (handle_can_close_key(sending_window, false)) {
					return -1;
				}
			} else {
				fprintf(stderr, "Invalid can_close value when handling window manager message: %s\n", value);
			}
		}
		// Handle the "Frame" command - controls whether window should be marked as managed by window manager
		else if (strcmp(key, "Frame") == 0) {
			if (strcmp(value, "Y") == 0) {
				handle_managed_key(sending_window, true);
			}
			else if (strcmp(value, "N") == 0) {
				handle_managed_key(sending_window, false);
			} else {
				fprintf(stderr, "Invalid Frame value when handling window manager message: %s\n", value);
			}
		}
		// Ignore Title message.
		else if (strcmp(key, "Title") == 0) {
			continue;
		}
		else {
			fprintf(stderr, "Unknown key when handling window manager message: %s\n", key);
		}
	}

	return 0;
}

int pause_callback(void * i) {
	int index = (int) i;
	int pid;
	// shift_window_handles_left moved index left ( - ) by 1
	if (screen_get_window_property_iv(created_windows[index - 1].handle, SCREEN_PROPERTY_OWNER_PID, &pid)) {
		LOG_ERROR("screen_get_window_property_iv(SCREEN_PROPERTY_OWNER_PID)");
		return -1;
	}
	// timeout in nanoseconds
	// 250ms = 250 000 000
	uint64_t timeout = 250000000;
	TimerTimeout(CLOCK_MONOTONIC, _NTO_TIMEOUT_NANOSLEEP, NULL, &timeout, NULL);
	if (kill(pid, SIGSTOP) > 0) {
		LOG_ERROR("kill");
		return -1;
	}
	created_windows[last_window_index - 1].is_paused = true;
	return 0;
}

int resume_window(int window_index) {
	// Get the Process ID of the application that owns the target window
	int pid;
	if (screen_get_window_property_iv(created_windows[window_index].handle, SCREEN_PROPERTY_OWNER_PID, &pid)) {
		LOG_ERROR("screen_get_window_property_iv(SCREEN_PROPERTY_OWNER_PID)");
		return -1;
	}

	// If window has been paused via signal, resume with CONT signal
	if (created_windows[window_index].is_paused) {
		if (kill(pid, SIGCONT) > 0) {
			LOG_ERROR("kill");
			return -1;
		}
		created_windows[window_index].is_paused = false;
	}
	return 0;
}

int close_window(int window_index) {
	// Get the Process ID of the application that owns the target window
	int pid;
	if (screen_get_window_property_iv(created_windows[window_index].handle, SCREEN_PROPERTY_OWNER_PID, &pid)) {
		LOG_ERROR("screen_get_window_property_iv(SCREEN_PROPERTY_OWNER_PID)");
		return -1;
	}

	// Attempt graceful close if the window is marked as managed
	if (created_windows[window_index].is_managed) {
		screen_event_t event;
		int type = SCREEN_EVENT_MANAGER;
		int subtype = SCREEN_EVENT_CLOSE;

		// Create the event object
		if (screen_create_event(&event)) {
			LOG_ERROR("screen_create_event");
		}
		// Set the event type to SCREEN_EVENT_MANAGER
		else if (screen_set_event_property_iv(event, SCREEN_PROPERTY_TYPE, &type)) {
			LOG_ERROR("screen_set_event_property_iv(SCREEN_PROPERTY_TYPE)");
		}
		// Associate the event with the specific window to be closed
		else if (screen_set_event_property_pv(event, SCREEN_PROPERTY_WINDOW, (void**)&created_windows[window_index].handle)) {
			LOG_ERROR("screen_set_event_property_pv(SCREEN_PROPERTY_WINDOW)");
		}
		// Set the event subtype to SCREEN_EVENT_CLOSE
		else if (screen_set_event_property_iv(event, SCREEN_PROPERTY_SUBTYPE, &subtype)) {
			LOG_ERROR("screen_set_event_property_iv(SCREEN_PROPERTY_SUBTYPE)");
		}
		// Flush context to ensure all event properties are set before sending
		else if (screen_flush_context(screen_ctx, 0)) {
			LOG_ERROR("screen_flush_context");
		}
		// Send the close event to the application process
		else if (screen_send_event(screen_ctx, event, pid)) {
			LOG_ERROR("screen_send_event");
		}
	}

	// If window is not marked as managed, force-kill the process
	else {
		if (kill(pid, SIGTERM) > 0) {
			LOG_ERROR("kill");
			return -1;
		}
	}

	return 0;
}

bool valid_window_handle(screen_window_t handle) {
	// Loop through all windows currently managed by the window manager
	for (int i = 0; i < num_windows(); i++) {
		// Check if the provided handle matches any of our managed windows
		if (created_windows[i].handle == handle) {
			return true;
		}
	}

	return false;
}

int main(int argc, char **argv)
{
	// d : demo -- pause (SIGSTOP) applications when not visible
	for (;;) {
		int const opt = getopt(argc, argv, "d");
		if (opt == 'd') {
			is_demo = true;
		} else if (opt == '?') {
			return 1;
		} else {
			break;
		}
	}

	// Ensure the number of taskbar previews per page is odd (for centering/highlighting logic)
	if (NUM_WINDOWS_PER_PAGE % 2 == 0) {
		printf("Expected an odd number of taskbar previews, currently configured for: %d\n", NUM_WINDOWS_PER_PAGE);
		return -1;
	}

	screen_window_t screen_win;    // native handle for our window
	screen_event_t screen_ev;      // handle used to pop events from our queue
	screen_window_t win;           // stores a window contained in an event
	int val;                       // used for simple property queries
	int rval = EXIT_FAILURE;       // application exits with value stored here

	// Create a Screen context with window manager and input provider capabilities
	if (screen_create_context(&screen_ctx, SCREEN_WINDOW_MANAGER_CONTEXT | SCREEN_INPUT_PROVIDER_CONTEXT)) {
		LOG_ERROR("screen_context_create");
		goto fail1;
	}

	int screen_ndisplays;

	// Query the number of available displays (monitors/screens)
	if (screen_get_context_property_iv(screen_ctx, SCREEN_PROPERTY_DISPLAY_COUNT, &screen_ndisplays)) {
		LOG_ERROR("screen_get_context_property_iv(SCREEN_PROPERTY_DISPLAY_COUNT)");
		goto fail2;
	}

	// Allocate an array to hold handles for each available display
	screen_display_t *screen_disp = calloc(screen_ndisplays, sizeof(*screen_disp));
	if (screen_disp == NULL) {
		LOG_ERROR("calloc");
		goto fail2;
	}

	// Fill the array with the actual display handles
	if (screen_get_context_property_pv(screen_ctx, SCREEN_PROPERTY_DISPLAYS, (void **)screen_disp)) {
		LOG_ERROR("screen_get_context_property_pv(SCREEN_PROPERTY_DISPLAYS)");
		goto fail3;
	}

	// For now, use the first display (could be extended to support multiple displays)
	screen_display_t screen_display = screen_disp[0];

	// Create the main window for the window manager
	if (screen_create_window(&screen_win, screen_ctx)) {
		LOG_ERROR("screen_create_window");
		goto fail3;
	}

	// Make sure window is always on top of all other windows so that it gets input (keyboard, etc) events
	int z_order = 2147483647;
	if (screen_set_window_property_iv(screen_win, SCREEN_PROPERTY_ZORDER, &z_order)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_ZORDER)");
		goto fail4;
	}

	// Set ID string for debugging via /dev/screen.
	const char *idstr = "window_manager";
	if (screen_set_window_property_cv(screen_win, SCREEN_PROPERTY_ID_STRING, strlen(idstr), idstr)) {
		LOG_ERROR("screen_set_window_property_cv(SCREEN_PROPERTY_ID_STRING)");
		goto fail4;
	}

	// Create a screen event to listen for input events
	if (screen_create_event(&screen_ev)) {
		LOG_ERROR("screen_create_event");
		goto fail4;
	}

	// Get the size (width and height) of the selected display
	if (screen_get_display_property_iv(screen_display, SCREEN_PROPERTY_SIZE, display_size)) {
		LOG_ERROR("screen_get_display_property_iv(SCREEN_PROPERTY_SIZE)");
		goto fail5;
	}

	int session_pos[2] = { 0, 0};

	// Create a session to handle keyboard input events
	screen_session_t kb_session;
	if (screen_create_session_type(&kb_session, screen_ctx, SCREEN_EVENT_KEYBOARD)) {
		LOG_ERROR("screen_create_session_type(SCREEN_EVENT_KEYBOARD)");
		goto fail5;
	}

	// Set the keyboard session's position to (0,0) (top-left of the display)
	if (screen_set_session_property_iv (kb_session, SCREEN_PROPERTY_POSITION, session_pos)) {
		LOG_ERROR("screen_set_session_property_iv(SCREEN_PROPERTY_POSITION)");
		goto fail6;
	}

	// Set the keyboard session's size to cover the entire display
	if (screen_set_session_property_iv (kb_session, SCREEN_PROPERTY_SIZE, display_size)) {
		LOG_ERROR("screen_set_session_property_iv(SCREEN_PROPERTY_SIZE)");
		goto fail6;
	}

	// Set the keyboard session's z-order so it is on top of other sessions/windows
	if (screen_set_session_property_iv(kb_session, SCREEN_PROPERTY_ZORDER, &z_order)) {
		LOG_ERROR("screen_set_session_property_iv(SCREEN_PROPERTY_ZORDER)");
		goto fail6;
	}

	// Associate the keyboard session with the selected display
	if (screen_set_session_property_pv(kb_session, SCREEN_PROPERTY_DISPLAY, (void**)&screen_display)) {
		LOG_ERROR("screen_set_session_property_pv(SCREEN_PROPERTY_DISPLAY)");
		goto fail6;
	}

	// Calculate the position (x, y) for the taskbar background
	int taskbar_pos[2];
	taskbar_position(taskbar_pos);

	// Calculate the size (width, height) for the taskbar background
	int taskbar_size_array[2];
	taskbar_size(taskbar_size_array);

	// Create the taskbar background window with the calculated size, position, color, and z-order
	if (create_taskbar_component(&taskbar_win, taskbar_size_array, taskbar_pos,
								TASKBAR_BG_COLOR, Z_ORDER_TASKBAR_BACKGROUND, "taskbar")) {
		LOG_ERROR("create_taskbar_component");
		goto fail6;
	}

	// Calculate the position (x, y) for the highlight window
	int taskbar_highlight_win_pos[2];
	taskbar_highlight_position(taskbar_highlight_win_pos);

	// Calculate the size (width, height) for the highlight window
	int taskbar_hightlight_win_size[2];
	taskbar_highlight_size(taskbar_hightlight_win_size);

	// Create the highlight window with the calculated size, position, highlight color, and z-order
	if (create_taskbar_component(&taskbar_highlight_win, taskbar_hightlight_win_size, taskbar_highlight_win_pos,
								TASKBAR_BG_COLOR_HIGHLIGHT_COLOR, Z_ORDER_TASKBAR_SELECTED_WIN, "taskbar_highlight")) {
		LOG_ERROR("create_taskbar_component");
		goto fail6;
	}


	int otype; 					// Variable to store the object type of screen events (window, display, device, etc.)
	last_window_index = -1; 	// Initialize the index of the last created window to -1 (no windows managed yet)
	selected_window_index = 0; 	// Initialize the index of the currently selected window to 0
	int taskbar_open = 0; 		// Flag to indicate whether the taskbar is currently open (0 = closed, 1 = open)
	int flags; 					// Variable to store event flags
	int cap; 					// Variable to store the key code from keyboard events
	int modifiers; 				// Variable to store modifier keys (Alt, Ctrl, Shift) from keyboard events

	// Set up sensitivity bitmask: window doesn't steal focus but can receive input events
	int main_session_sensitivity =  SCREEN_SENSITIVITY_MASK_NO_FOCUS | SCREEN_SENSITIVITY_MASK_CONTINUE;

	// Apply the sensitivity settings to the main window
	if(screen_set_window_property_iv(screen_win, SCREEN_PROPERTY_SENSITIVITY, &main_session_sensitivity)) {
		LOG_ERROR("screen_set_window_property_iv(SCREEN_PROPERTY_SENSITIVITY)");
		goto fail6;
	}

	int num_devices;
	// Query the number of available input devices
	if (screen_get_context_property_iv(screen_ctx, SCREEN_PROPERTY_DEVICE_COUNT, &num_devices)) {
		LOG_ERROR("screen_get_context_property_iv(SCREEN_PROPERTY_DEVICE_COUNT)");
		goto fail6;
	}

	// Allocate memory for an array to hold handles to all input devices
	screen_device_t *devices = calloc(num_devices, sizeof(*devices));
	if (devices == NULL) {
		LOG_ERROR("calloc");
		goto fail6;
	}

	// Fill the array with handles to all available input devices (keyboards, mice, etc.)
	if (screen_get_context_property_pv(screen_ctx, SCREEN_PROPERTY_DEVICES, (void **)devices)) {
		LOG_ERROR("screen_get_context_property_pv(SCREEN_PROPERTY_DEVICES)");
		goto fail7;
	}

	// Loop through each input device to find and configure keyboard devices
	for (int i = 0; i < num_devices; i++) {
		int device_type;
		// Get the type of the current device (keyboard, mouse, touch, etc.)
		if (screen_get_device_property_iv(devices[i], SCREEN_PROPERTY_TYPE, &device_type)) {
			LOG_ERROR("screen_get_device_property_iv(SCREEN_PROPERTY_TYPE)");
			goto fail7;
		}

		// If this device is a keyboard, associate it with our keyboard session
		if (device_type == SCREEN_EVENT_KEYBOARD) {
			if (screen_set_device_property_pv(devices[i], SCREEN_PROPERTY_SESSION, (void**)&kb_session)) {
				LOG_ERROR("screen_set_device_property_iv(SCREEN_PROPERTY_SESSION)");
				goto fail7;
			}
		}
	}

	// Set the display to use manual focus mode so the window manager controls which window has focus
	int focus_mode = SCREEN_FOCUS_MODE_MANUAL;
	if (screen_set_display_property_iv(screen_display, SCREEN_PROPERTY_FOCUS_MODE, &focus_mode)) {
		LOG_ERROR("screen_set_display_property_iv(SCREEN_PROPERTY_FOCUS_MODE)");
		goto fail7;
	}

	// Ensure the screen context processes all pending commands immediately
	if (screen_flush_context(screen_ctx, 0)) {
		LOG_ERROR("screen_flush_context");
		goto fail7;
	}

	// Variables when app calls screen_manage_window()
	char manager_message[512]; 										// Buffer to store messages sent from managed applications
	screen_window_t sending_window_handle; 							// Handle to the window sending a manager message
	const char *manager_response = "simple-fullscreen-win-manager"; // Response string sent back to applications

	int rc; // Return code

	// Main loop: runs the window manager until an error or exit condition occurs
	while (1) {
		// Inner loop: waits for and processes events from the QNX Screen system
		while (0 == (rc = screen_get_event(screen_ctx, screen_ev, ~0))) {
			// Retrieve the type of the current event
			if (screen_get_event_property_iv(screen_ev, SCREEN_PROPERTY_TYPE, &val)) {
				LOG_ERROR("screen_get_event_property_iv(SCREEN_PROPERTY_TYPE)");
				goto fail7;
			}

			// Retrieve the object type of the event
			if (screen_get_event_property_iv(screen_ev, SCREEN_PROPERTY_OBJECT_TYPE, &otype)) {
				LOG_ERROR("screen_get_event_property_iv(SCREEN_PROPERTY_OBJECT_TYPE)");
				goto fail7;
			}

			// Handle new device creation events (e.g., when a new keyboard is plugged in)
			if (val == SCREEN_EVENT_CREATE && otype == SCREEN_OBJECT_TYPE_DEVICE) {
				screen_device_t device;

				// Get the handle to the newly created device
				if (screen_get_event_property_pv(screen_ev, SCREEN_PROPERTY_DEVICE, (void**)&device)) {
					LOG_ERROR("screen_get_event_property_pv(SCREEN_PROPERTY_DEVICE)");
					goto fail7;
				}

				int device_type;
				// Get the type of the device (keyboard, mouse, touch, etc.)
				if (screen_get_device_property_iv(device, SCREEN_PROPERTY_TYPE, &device_type)) {
					LOG_ERROR("screen_get_device_property_iv(SCREEN_PROPERTY_TYPE)");
					goto fail7;
				}

				// If the new device is a keyboard, associate it with our keyboard session
				if (device_type == SCREEN_EVENT_KEYBOARD) {
					if (screen_set_device_property_pv(device, SCREEN_PROPERTY_SESSION, (void**)&kb_session)) {
						LOG_ERROR("screen_set_device_property_iv(SCREEN_PROPERTY_SESSION)");
						goto fail7;
					}

					// Flush the context to ensure the device association is applied
					if (screen_flush_context(screen_ctx, 0)) {
						LOG_ERROR("screen_flush_context");
						goto fail7;
					}
				}
			}

			// Handle manager events (special messages from applications to the window manager)
			if (val == SCREEN_EVENT_MANAGER) {
				int message_length;
				// Get the length of the manager message
				if (screen_get_event_property_iv(screen_ev, SCREEN_PROPERTY_SIZE, &message_length)) {
					LOG_ERROR("screen_get_event_property_iv(SCREEN_PROPERTY_SIZE)");
					goto fail7;
				}

				// Size of buffer when getting message must be same size as message; otherwise a failure occurs retrieving the message
				int max_message_length = sizeof(manager_message) - 1; // Reserve last index for null-terminating character
				message_length = min(message_length, max_message_length);

				// Retrieve the actual manager message content
				if (screen_get_event_property_cv(screen_ev, SCREEN_PROPERTY_USER_DATA, message_length, manager_message)) {
					LOG_ERROR("screen_get_event_property_cv(SCREEN_PROPERTY_USER_DATA)");
					goto fail7;
				}

				// Ensure the message is null-terminated
				manager_message[message_length] = '\0';

				// Get the handle to the window that sent this manager message
				if (screen_get_event_property_pv(screen_ev, SCREEN_PROPERTY_WINDOW, (void**)&sending_window_handle)) {
					LOG_ERROR("screen_get_event_property_cv(SCREEN_PROPERTY_WINDOW)");
					return -1;
				}

				// Verify that the sending window is valid
				if (!valid_window_handle(sending_window_handle)) {
					break;
				}

				// Process the manager message and update window manager state accordingly
				if (process_manager_message(sending_window_handle, manager_message)) {
					goto fail7;
				}
			}

			// Handle keyboard events on the display (Alt+Tab, Alt+Tab+Delete, etc.)
			if (otype == SCREEN_OBJECT_TYPE_DISPLAY && val == SCREEN_EVENT_KEYBOARD) {
				// Get the event flags to determine if key was pressed
				if (screen_get_event_property_iv(screen_ev, SCREEN_PROPERTY_FLAGS, &flags)) {
					LOG_ERROR("screen_get_event_property_iv(SCREEN_PROPERTY_FLAGS)");
					goto fail7;
				}

				// Get the key code (which specific key was pressed - Tab, Delete, etc.)
				if (screen_get_event_property_iv(screen_ev, SCREEN_PROPERTY_KEY_CAP, &cap)) {
					LOG_ERROR("screen_get_event_property_iv(SCREEN_PROPERTY_KEY_CAP)");
					goto fail7;
				}

				// Get modifier keys (Alt, Ctrl, Shift) to detect key combinations
				if (screen_get_event_property_iv(screen_ev, SCREEN_PROPERTY_MODIFIERS, &modifiers)) {
					LOG_ERROR("screen_get_event_property_iv(SCREEN_PROPERTY_MODIFIERS)");
					goto fail7;
				}

				int event_handled = 0;

				// Handle key down events (when keys are pressed)
				if (flags & KEY_DOWN) {
					// Handle Alt+Tab: Open taskbar and cycle through windows
					if (cap == KEYCODE_TAB && (modifiers & KEYMOD_ALT)) {
						// If taskbar is not open, start with the most recent window
						if (!taskbar_open) {
							selected_window_index = last_window_index;
						}

						// Move to the previous window in the list
						selected_window_index -= 1;
						// Wrap around to the last window if we go below 0
						if (selected_window_index <= -1) {
							selected_window_index = num_windows() - 1;
						}

						// Reorganize the taskbar to show the new selection
						if (organize_taskbar(selected_window_index)) {
							LOG_ERROR("organize_taskbar");
							goto fail7;
						}

						// Make the taskbar visible
						if (!taskbar_open && change_taskbar_visibility(true)) {
							LOG_ERROR("change_taskbar_visibility");
							goto fail7;
						}

						taskbar_open = 1;
						event_handled = 1;
					}
					// Handle Alt+Tab+Delete: Close the currently selected window. At least one window must be open for this to have an effect.
					else if (cap == KEYCODE_DELETE && (modifiers & KEYMOD_ALT) && last_window_index >= 0 && taskbar_open && created_windows[selected_window_index].can_be_closed) {
						// Close the selected window if all conditions are met
						if (close_window(selected_window_index)) {
							goto fail7;
						}

						// Adjust selected window index
						if (selected_window_index > 0){
							selected_window_index--;
						} else {
							selected_window_index = last_window_index;
						}
						event_handled = 1;
					}
				}
				// Handle Alt key release: activate the selected window and close taskbar
				else if (!(modifiers & KEYMOD_ALT) && taskbar_open) {
					if (last_window_index >= 0) {
						window_t temp = created_windows[selected_window_index];
						shift_window_handles_left(selected_window_index);
						created_windows[last_window_index] = temp;

						if (is_demo) {
							// Resume selected application/window
							resume_window(last_window_index);
						}
						// Hide all other windows and show only the selected window
						if (change_new_window_visibility()) {
							goto fail7;
						}

						// Set focus to the selected window for input focus
						if (screen_set_display_property_pv(screen_display, SCREEN_PROPERTY_FOCUS, (void**)&created_windows[last_window_index].handle)) {
							LOG_ERROR("screen_set_display_property_pv(SCREEN_PROPERTY_FOCUS)");
							goto fail7;
						}

						// Pause the previous running application/window
						if (last_window_index > 0 && is_demo) {
							// initialize the attribute structure
							pthread_attr_t attr;
							pthread_attr_init(&attr);
							// set the detach state to "detached"
							pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
							pthread_create(NULL, &attr, (void *)pause_callback, (void *)last_window_index);
						}

						// Apply all changes to the display
						if (screen_flush_context(screen_ctx, 0)) {
							LOG_ERROR("screen_flush_context");
							goto fail7;
						}

					}

					// Hide the taskbar since Alt+Tab selection is complete
					if (change_taskbar_visibility(false)) {
						goto fail7;
					}

					taskbar_open = 0;
					event_handled = 1;
				}

				// Handle unhandled keyboard events: pass them through to the focused application
				if (!event_handled) {
					int *p = NULL;
					// Clear the device association from the event so it can be passed to any window
					if (screen_set_event_property_pv(screen_ev, SCREEN_PROPERTY_DEVICE, (void**) &p)) {
						LOG_ERROR("screen_set_event_property_pv(SCREEN_PROPERTY_DEVICE)");
						goto fail7;
					}

					// Ensure all pending Screen API operations are completed before injecting the event
					if (screen_flush_context(screen_ctx, 0)) {
						LOG_ERROR("sscreen_flush_context");
						goto fail7;
					}

					// Inject the unhandled event back to the display so it reaches the focused window
					if(screen_inject_event(screen_display, screen_ev)) {
						LOG_ERROR("screen_inject_event");
						goto fail7;
					}
				}
			}

			if (otype == SCREEN_OBJECT_TYPE_WINDOW) {
				switch (val) {
				case SCREEN_EVENT_CREATE:
					// Check if we haven't reached the maximum number of windows we can manage
					if(num_windows() < MAX_NUM_WINDOWS) {
						// Get the window handle from the event and add it to our tracking array
						if (screen_get_event_property_pv(screen_ev, SCREEN_PROPERTY_WINDOW, (void **)&created_windows[++last_window_index].handle)) {
							LOG_ERROR("screen_get_event_property_pv(SCREEN_PROPERTY_WINDOW)");
							goto fail7;
						}

						// Initialize default properties for the new window
						created_windows[last_window_index].taskbar_preview = NULL;  // No taskbar preview yet - will be created when SCREEN_EVENT_POST event occurs
						created_windows[last_window_index].can_be_closed = true;   	// Window can be closed by Alt+Delete by default
						created_windows[last_window_index].is_managed = false;     	// Window is set to not managed by default
						created_windows[last_window_index].is_paused = false;    // By default, window has not been paused by signal
						created_windows[last_window_index].renders_with_child_windows = false;	// Determines if taskbar preview is sharing buffers or using screenshot
					}
					// If we've reached the window limit, reject the new window and kill the creating application
					else {
						fprintf(stderr, "Only a maximum of %d windows can be managed\n\r", MAX_NUM_WINDOWS);

						// Get the window handle and PID of the rejected window
						screen_window_t win;
						int pid;

						if (screen_get_event_property_pv(screen_ev, SCREEN_PROPERTY_WINDOW, (void **)&win)) {
							LOG_ERROR("screen_get_event_property_pv(SCREEN_PROPERTY_WINDOW)");
						}

						if (screen_get_window_property_iv(win, SCREEN_PROPERTY_OWNER_PID, &pid)) {
							LOG_ERROR("screen_get_window_property_iv(SCREEN_PROPERTY_OWNER_PID)");
						}
						// Terminate the application that tried to create the window beyond our limit
						else if(kill(pid, SIGTERM) > 0) {
							LOG_ERROR("kill");
						}
					}

					break;
				case SCREEN_EVENT_PROPERTY:
					int name;
					// Get the specific property name that changed
					if (screen_get_event_property_iv(screen_ev, SCREEN_PROPERTY_NAME, &name)) {
						LOG_ERROR("screen_get_event_property_iv");
						goto fail7;
					}

					// Switch on the specific property type that changed
					switch(name) {
						// Handle manager string property - this is triggered when apps call screen_manage_window()
						// or set the SCREEN_PROPERTY_MANAGER_STRING property
						// The app is BLOCKED waiting for our response and we must process this to unblock them
						case SCREEN_PROPERTY_MANAGER_STRING:


							// Get the window handle that sent this property change
							if (screen_get_event_property_pv(screen_ev, SCREEN_PROPERTY_WINDOW, (void**)&sending_window_handle)) {
								LOG_ERROR("screen_get_event_property_iv(SCREEN_PROPERTY_WINDOW)");
								goto fail7;
							}

							// Verify that the sending window is valid
							if (!valid_window_handle(sending_window_handle)) {
								break;
							}

							// Read the management request from the window's property (e.g., "Frame=Y")
							// This contains the string passed by the app
							if (screen_get_window_property_cv(sending_window_handle, SCREEN_PROPERTY_MANAGER_STRING,  sizeof(manager_message), manager_message)) {
								LOG_ERROR("screen_get_window_property_cv(SCREEN_PROPERTY_MANAGER_STRING)");
								goto fail7;
							}

							// Ensure the message is null-terminated for safe string handling
							manager_message[sizeof(manager_message) - 1] = '\0';

							// Process the manager message and update window manager state accordingly
							if (process_manager_message(sending_window_handle, manager_message)) {
								goto fail7;
							}

							// Send response back to unblock the app's screen_manage_window() call
							if (screen_set_window_property_cv(sending_window_handle, SCREEN_PROPERTY_MANAGER_STRING, strlen(manager_response), manager_response)) {
								LOG_ERROR("screen_set_window_property_cv(SCREEN_PROPERTY_MANAGER_STRING)");
								goto fail7;
							}

							// Flush the context to ensure the response is sent immediately
							if (screen_flush_context(screen_ctx, 0)) {
								LOG_ERROR("screen_flush_context");
								goto fail7;
							}

							break;
						default:
							break;
					}
					break;
				case SCREEN_EVENT_CLOSE:
					// Handle window close events - triggered when apps close their windows or window manager forces closure

					// Get the window handle of the window being closed
					if (screen_get_event_property_pv(screen_ev, SCREEN_PROPERTY_WINDOW, (void **)&win)) {
						LOG_ERROR("screen_get_event_property_pv(SCREEN_PROPERTY_WINDOW)");
						goto fail7;
					}

					int found_window = 0;

					// Search through our managed windows to find the one being closed
					for (int window_index = 0; window_index < num_windows(); window_index++) {
						if (win == created_windows[window_index].handle) {

							// Destroy the taskbar preview window for this window
							if (created_windows[window_index].taskbar_preview) {
								if (screen_destroy_window(created_windows[window_index].taskbar_preview)) {
									LOG_ERROR("screen_destroy_window");
									goto fail7;
								}
							}

							// Remove the window from our tracking array and shift remaining windows left
							shift_window_handles_left(window_index);
							last_window_index -= 1;
							found_window = 1;

							// Update window manager state if there are still windows remaining
							if (last_window_index >= 0) {
								// Adjust selected window index if it was pointing to the closed window
								if (selected_window_index > last_window_index) {
									selected_window_index = last_window_index;
								}

								// Reorganize the taskbar to reflect the remaining windows
								if (organize_taskbar(selected_window_index)) {
									LOG_ERROR("organize_taskbar");
									goto fail7;
								}

								// Update window visibility to show the most recent remaining window
								if (change_new_window_visibility()) {
									goto fail7;
								}
							}

							break;
						}
					}

					// Handle case where we received a close event for a window we're not tracking
					if (!found_window) {
						fprintf(stderr, "Warning- window being deleted is not tracked by window manager - ignoring it\n");
						continue;
					}

					// Destroy the window and free resources
					if (screen_destroy_window(win)) {
						LOG_ERROR("screen_destroy_window");
						goto fail7;
					}

					// Flush the context
					if (screen_flush_context(screen_ctx, 0)) {
						LOG_ERROR("screen_flush_context");
						goto fail7;
					}

					break;
				case SCREEN_EVENT_POST:

					// Get the window handle of the window that posted content
					if (screen_get_event_property_pv(screen_ev, SCREEN_PROPERTY_WINDOW, (void **)&win)) {
						LOG_ERROR("screen_get_event_property_pv(SCREEN_PROPERTY_WINDOW)");
						goto fail7;
					}

					// Search through our managed windows to find the posting window
					int posting_window_index = -1;
					for(int i = 0; i < num_windows(); i++) {
						if (created_windows[i].handle == win) {
							posting_window_index = i;
							break;
						}
					}

					// Handle case where we received a post event for a window we're not tracking
					if (posting_window_index == -1) {
						fprintf(stderr, "Warning- window that posted is not tracked by window manager - ignoring it\n");
					}
					// Set input focus to the posting window
					else if (screen_set_display_property_pv(screen_display, SCREEN_PROPERTY_FOCUS, (void**)&created_windows[posting_window_index].handle)) {
						LOG_ERROR("screen_set_display_property_pv(SCREEN_PROPERTY_FOCUS)");
						goto fail7;
					}
					// Initialize the window for window manager integration (create taskbar preview, set properties)
					else if (init_window(&created_windows[posting_window_index], taskbar_open)) {
						LOG_ERROR("init_window");
						goto fail7;
					}
					// Update the taskbar to include the new window's preview
					else if (organize_taskbar(selected_window_index)) {
						LOG_ERROR("organize_taskbar");
						goto fail7;
					}

					break;
				}
			}
		}

		if (rc) {
			// exit outer while loop
			LOG_ERROR("screen_get_event");
			break;
		}
	}

	rval = EXIT_SUCCESS;

fail7:
	for (int i = 0; i < num_windows(); i++) {
		if (created_windows[i].taskbar_preview) {
			screen_destroy_window(created_windows[i].taskbar_preview);
		}
	}

  screen_destroy_window(taskbar_win);
  screen_destroy_window(taskbar_highlight_win);

  free(devices);

fail6:
	screen_destroy_session(kb_session);
fail5:
	screen_destroy_event(screen_ev);
fail4:
	screen_destroy_window(screen_win);
fail3:
	free(screen_disp);
fail2:
	screen_destroy_context(screen_ctx);
fail1:

	return rval;
}
