# screen-demos-qnxeverywhere

## Apps

### demolauncher

App launcher for QNXE.

### fullscreen-winmgr

Window manager for QNXE.

## Building
- Source QNX SDP. e.g.
```
$ source ~/qnx800/qnxsdp-env.sh
```
- Run the following command in the root directory of the project
```
$ make
```

## Minimum Requirements
- com.qnx.qnx800.target/0.0.1.00135T202311191043L
- com.qnx.qnx800.host.linux.x86_64/0.0.1.00135T202311191043L
- com.qnx.qnx800.target.screen.fonts.engine/0.0.1.00020T202311191218L
- com.qnx.qnx800.target.screen.img_codecs/0.0.1.00022T202311191206L
