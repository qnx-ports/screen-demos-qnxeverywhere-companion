/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include <screen/screen.h>
#include "demolauncher.h"
#include <string.h>
#include <netinet/in.h>
#include <ifaddrs.h>
#include <sys/socket.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <net/route.h>
#include <unistd.h>
#include <pthread.h>

int routeSocket_;
int ifIndex_;
struct in_addr addr_;
char buf_ip[20] = "IP: ";

void*
monitor_ipc_changes(void* data)
{
    struct {
        struct ifa_msghdr hdr;
        char data[256];
    } msg;
    screen_context_t context = (screen_context_t) data;

    // Create an event that can later be filled with event data
    screen_event_t screen_ev = NULL;
    if (screen_create_event(&screen_ev)) {
        perror("screen_create_event(&screen_ev)");

    }

    pid_t pid = getpid();

    // Set the event type property to "user" event.
    int value = SCREEN_EVENT_USER;
    if (screen_set_event_property_iv(screen_ev, SCREEN_PROPERTY_TYPE, &value)) {
        perror("screen_set_event_property_iv(SCREEN_PROPERTY_TYPE)");
    }

    for (;;) {
        // Wait for notifications.
        ssize_t len = recv(routeSocket_, &msg, sizeof(msg), 0);
        if (len == -1) {
            perror("Failed to receive on routing socket");
            sleep(10);
            continue;
        }

        if (msg.hdr.ifam_type == RTM_NEWADDR) {
            // New address available.
            // Only handle if address is not set
            if (addr_.s_addr != 0) {
                continue;
            }

            // Iterate over all sockaddr structures in the payload.
            char *ptr = msg.data;
            char *end = ((char *)&msg) + len;
            int addr_index = 0;
            for (;;) {
                struct sockaddr_in *addr = (struct sockaddr_in *)ptr;
                if ((msg.hdr.ifam_addrs & (1U << addr_index)) != 0) {
                    // sockaddr structure is applicable.
                    if (addr->sin_family == PF_INET) {
                        addr_ = addr->sin_addr;
                        ifIndex_ = msg.hdr.ifam_index;
                        // Send an event to indicate IP address update.
                        screen_send_event(context, screen_ev, pid);
                        // pthread_exit(NULL);
                    }
                }
                ptr += ((struct sockaddr *)ptr)->sa_len;
                if (ptr >= end) {
                    break;
                }

                addr_index++;
            }
        } else if (msg.hdr.ifam_type == RTM_DELADDR) {
            // Address disappeared.
            if (ifIndex_ == 0) {
                continue;
            }

            if (msg.hdr.ifam_index == ifIndex_) {
                addr_.s_addr = 0;
                screen_send_event(context, screen_ev, pid);
                ifIndex_ = -1;
            }
        }
    }

    return NULL;
}


void
initialize_ipc_monitor(screen_context_t context) {
    addr_.s_addr = 0;
    routeSocket_ = socket(PF_ROUTE, SOCK_RAW, PF_INET);
    pthread_t thread;
    if (routeSocket_ != -1) {
        pthread_create(&thread, NULL, monitor_ipc_changes, (void *) context);
    } else {
        perror("Failed to create routing socket");
    }

    getIP();
}

/*
 *  Try retrieve IP and store it into a string
*/
void
getIP() {
    // Get all network addresses.
    struct ifaddrs *addrs;
    if (getifaddrs(&addrs) == -1) {
        perror("waiting");
        return;
    }

    // Look for a PF_INET address for an interface that is UP and not LOOPBACK.
    for (struct ifaddrs *addr = addrs; addr != NULL; addr = addr->ifa_next) {
        if (addr->ifa_addr->sa_family != PF_INET) {
            continue;
        }

        if ((addr->ifa_flags & (IFF_UP | IFF_LOOPBACK)) == IFF_UP) {
            addr_ = ((struct sockaddr_in *)(addr->ifa_addr))->sin_addr;
            ifIndex_ = if_nametoindex(addr->ifa_name);
            break;
        }
    }

    if (addr_.s_addr == 0) {
        strcpy(buf_ip, "IP NOT AVAILABLE");
    } else {
        strcpy(buf_ip, "IP: ");
        strcpy(buf_ip + 4, inet_ntoa(addr_));
    }

    freeifaddrs(addrs);
}