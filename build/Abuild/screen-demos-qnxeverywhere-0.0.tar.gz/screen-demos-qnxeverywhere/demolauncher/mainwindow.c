/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include <unistd.h>
#include <stdbool.h>
#include <screen/screen.h>
#include "demolauncher.h"
#include <string.h>

#define VERSION_FILE_PATH "/usr/share/demolauncher/version.txt"
#define QNX_FONT_PATH "/usr/share/fonts/dejavu/DejaVuSansCondensed.ttf"
#define DEFAULT_FONT_PATH "/usr/share/fonts/dejavu/DejaVuSansCondensed.ttf"

textbox_t textbox = {
        .font_path = DEFAULT_FONT_PATH,
        .rect = {10, 690, 300, 30},
        .ptsize = {13, 13},
        .window = NULL
};

textbox_t textbox2 = {
        .font_path = DEFAULT_FONT_PATH,
        .rect = {10, 690, 300, 30},
        .ptsize = {13, 13},
        .window = NULL
};

bool
mainwindow_create(screen_context_t context, screen_window_t *windowp,
                  char const *background, char *window_group_name,
                  char const *dpi_calc)
{
    struct png_info png_info;
    bool using_color_background = false;

    // Create a window that can be used to make graphical content visible on a display
    screen_window_t window;
    if (screen_create_window(&window, context)) {
        perror("screen_create_window");
        return false;
    }

    // Retrieve the display associated with the window.
    screen_display_t display;
    if (screen_get_window_property_pv(window, SCREEN_PROPERTY_DISPLAY, (void **)&display)) {
        perror("screen_get_window_property_pv(SCREEN_PROPERTY_DISPLAY)");
    }

    // Get the display size (width and height in pixels).
    int size[2];
    if (screen_get_display_property_iv(display, SCREEN_PROPERTY_SIZE, size)) {
        perror("screen_get_display_property_iv(SCREEN_PROPERTY_SIZE)");
    }

    // Define a rectangle that represents the full-screen area.
    // rect[0], rect[1] → X, Y position (top-left corner).
    // rect[2], rect[3] → Width and Height of the window.
    int rect[] = { 0, 0, size[0], size[1] };

    // Set the window position to (0,0), placing it at the top-left corner.
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_POSITION, &rect[0])) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_POSITION)");
        return false;
    }

    // Set the window size to match the display size, making it full screen.
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_SIZE, &rect[2])) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
        return false;
    }

    /*
        This next block of code will load
        the background image to the display monitor
    */

    // Use the background image based on the size of the display
    char res_adjusted_image_name[512] = {0};
    strncpy(res_adjusted_image_name, background, sizeof(res_adjusted_image_name) - 1);

#define RES_1080P_X 1920
#define RES_1080P_Y 1080
#define RES_720P_X 1280
#define RES_720P_Y 720

    if (size[0] == RES_1080P_X && size[1] == RES_1080P_Y) {
        strncat(res_adjusted_image_name, "_1080p.png", sizeof(res_adjusted_image_name) - strlen(res_adjusted_image_name) - 1);
    }
    else if (size[0] == RES_720P_X && size[1] == RES_720P_Y) {
        strncat(res_adjusted_image_name, "_720p.png", sizeof(res_adjusted_image_name) - strlen(res_adjusted_image_name) - 1);
    }
    else {
        fprintf(stderr, "Expected resolution to be either 1080p or 720p, demolauncher will proceed with 1080p assumption\n");
        strncat(res_adjusted_image_name, "_1080p.png", sizeof(res_adjusted_image_name)  - strlen(res_adjusted_image_name) - 1);
    }

    // Try to initialize PNG, if it fails, use blue background
    if(!png_init(&png_info, res_adjusted_image_name)) {
        fprintf(stderr, "Failed to load background image, using blue background\n");
        using_color_background = true;
    }

    // Set buffer size based on either PNG or display size
    int buffer_size[2];
    if (!using_color_background) {
        buffer_size[0] = png_info.width;
        buffer_size[1] = png_info.height;
    } else {
        buffer_size[0] = size[0];
        buffer_size[1] = size[1];
    }

    if(screen_set_window_property_iv(window, SCREEN_PROPERTY_BUFFER_SIZE, buffer_size)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_BUFFER_SIZE)");
        return false;
    }

    // Create the window buffers with the size of SCREEN_PROPERTY_BUFFER_SIZE as set for the window.
    if (screen_create_window_buffers(window, 1)) {
        perror("screen_create_window_buffers");
        return false;
    }

    // Retrieve the buffer associated with the window. This buffer will hold the image.
    screen_buffer_t buf;
    if(screen_get_window_property_pv(window, SCREEN_PROPERTY_BUFFERS, (void**)&buf)) {
        perror("screen_get_window_property_pv(SCREEN_PROPERTY_BUFFERS)");
        return false;
    }

    if (using_color_background) {

        // Define attributes for positioning and blue color
        int attribs[] = {
            SCREEN_BLIT_DESTINATION_X, rect[0],
            SCREEN_BLIT_DESTINATION_Y, rect[1],
            SCREEN_BLIT_DESTINATION_WIDTH, rect[2],
            SCREEN_BLIT_DESTINATION_HEIGHT, rect[3],
            SCREEN_BLIT_COLOR, 0x000000FF,
            SCREEN_BLIT_END
        };

        // Fill the screen with blue color
        if (screen_fill(context, buf, attribs) != 0) {
            perror("screen_fill");
            return false;
        }
    } else {
        // Load the background PNG image into the retrieved buffer
        if(!png_load(&png_info, buf)) {
            perror("failed to load the png");
            return false;
        }
    }

    // Create a window group for the 3 launch icon child windows.
    // Pass in NULL pointer for screen to generate a name for the child window
    if (screen_create_window_group(window, NULL)) {
        perror("screen_create_window_group");
        return false;
    }

    // Retrieve the window group name and stores it in window_group_name variable
    if (screen_get_window_property_cv(window, SCREEN_PROPERTY_GROUP, WINDOW_GROUP_NAME_SIZE - 1, window_group_name)) {
        perror("screen_get_window_property_cv(SCREEN_PROPERTY_GROUP)");
        return false;
    }

    /*
        This next block of code will display icon for apps in the
        display monitor and calculate their positioning and sizes
    */

    // Calculates the size and position of application icons based on the screen resolution, resizing them
    // proportionally and positioning them horizontally (left, center, right) with appropriate padding.
    const int base_app_size = 90;
    float resize_factor_x = buffer_size[0] / (float)RES_720P_X;
    float resize_factor_y = buffer_size[1] / (float)RES_720P_Y;

    int app_size_x = base_app_size * resize_factor_x;
    int app_size_y = base_app_size * resize_factor_y;

#define MAX_PADDING_BETWEEN_ICONS 90
#define MAX_PADDING_BETWEEN_ROWS 20

    // num_rows specifies how may rows of icons to configure on the main page.
    // The row array contains how many icons to display per row.
    // The sum of the values in the row array should equal app_count.
    // To change the layout, change those two variables.
    // Note: The icons in each row are centered.

    int num_rows = 0;
    int row[2] = {0, 0};

    switch (app_count){
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            num_rows = 1;
            row[0] = app_count;
            break;
        case 6:
            num_rows = 2;
            row[0] = 3;
            row[1] = 3;
            break;
        case 7:
        case 8:
            num_rows = 2;
            row[0] = 4;
            row[1] = app_count - 4;
            break;
        case 9:
        case 10:
            num_rows = 2;
            row[0] = 5;
            row[1] = app_count - 5;
            break;
        default:
            fprintf(stderr, "Invalid app_count\n");
            return false;
    }

    int apps_index = 0;
    const int padding_between_rows = MAX_PADDING_BETWEEN_ROWS * resize_factor_y;
    int starting_point_x = 0;
    int starting_point_y = 0;

    for (int j = 0; j < num_rows && apps_index < app_count; j++) {
        int row_app_count = row[j];

        const int calculated_base_padding_between_icons = (RES_720P_X - row_app_count * base_app_size) / (row_app_count + 1);
        const int base_padding_between_icons = calculated_base_padding_between_icons > MAX_PADDING_BETWEEN_ICONS ? MAX_PADDING_BETWEEN_ICONS : calculated_base_padding_between_icons;
        const int padding_between_icons = base_padding_between_icons * resize_factor_x;

        //padding_between_icons = MAX_PADDING_BETWEEN_ICONS * resize_factor_x;
        starting_point_x = (buffer_size[0] - (app_size_x * row_app_count) - ((row_app_count - 1) * padding_between_icons)) / 2;

        // The y position did not adjust for the icon size, so we have a special case for one row here to handle it.
        starting_point_y = num_rows == 1 ? buffer_size[1]/2 : (float) buffer_size[1]/2 - ((app_size_y * (num_rows-1))/2) - ((num_rows - 1) * padding_between_rows/2);

        for (int i = 0; i < row_app_count && apps_index < app_count; i++) {
            apps[apps_index].rect[0] = starting_point_x + i * (app_size_x + padding_between_icons);
            apps[apps_index].rect[1] = starting_point_y + (j * (app_size_y + padding_between_rows));
            apps[apps_index].rect[2] = app_size_x;
            apps[apps_index].rect[3] = app_size_y;

            // Create the application icon using the calculated properties
            appicon_create(context, &apps[apps_index], window_group_name);

            apps_index++;
        }
    }

    // Create the focus window
    appicon_focus_create(context, app_size_x, app_size_y, window_group_name);

    /*
        This next block of code will display text for ip address
        and build number of the image on the display monitor
        while also calculating their size and posiitoning
    */

    // Set textbox position and display it on screen
    initialize_ipc_monitor(context);
    if (access(QNX_FONT_PATH, F_OK) == 0) {
      textbox.font_path = QNX_FONT_PATH;
      textbox2.font_path = QNX_FONT_PATH;
    }
    textbox.text = buf_ip;
    textbox.rect[0] *= resize_factor_x;
    textbox.rect[1] *= resize_factor_y;
    textbox.rect[2] *= resize_factor_x;
    textbox.rect[3] *= resize_factor_y;
    textbox.mainwindow = window;

    // Create the textbox
    text_create(context, &textbox, window_group_name, dpi_calc);

    // Set textbox2's position to be to the right of textbox
    textbox2.rect[0] = textbox.rect[0] + textbox.rect[2];
    textbox2.rect[1] = textbox.rect[1];
    textbox2.rect[2] *= resize_factor_x;
    textbox2.rect[3] *= resize_factor_y;
    textbox2.mainwindow = window;
    FILE *version_file = fopen(VERSION_FILE_PATH, "r");
    if (version_file) {
        // Read the content of the file into a buffer
        char version_content[20];
        if (fgets(version_content, sizeof(version_content), version_file) != NULL) {
            // Set the text for textbox2
            textbox2.text = strdup(version_content);
        } else {
            // Handle empty or unreadable file
            textbox2.text = "BUILD: UNKNOWN";
        }
        fclose(version_file);
    } else {
        // Handle file not found or unreadable
        textbox2.text = "BUILD: UNKNOWN";
    }

    // Create the new textbox
    text_create(context, &textbox2, window_group_name, dpi_calc);

    // Post the window to make the changes done to the window visible
    if (screen_post_window(window, buf, 1, rect, 0)) {
        perror("screen_post_window");
        return false;
    }

    *windowp = window;
    return true;
}
