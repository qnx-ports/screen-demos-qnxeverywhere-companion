ifndef QCONFIG
QCONFIG=qconfig.mk
endif
include $(QCONFIG)

define PINFO
PINFO DESCRIPTION = Demo for a grid based application launcher
endef
INSTALLDIR=
NAME=demolauncher
USEFILE=

LIBS=screen png16 freetype socket
INCVPATH=${QNX_TARGET}/usr/include/freetype2

# install assets
POST_INSTALL+=$(CP_HOST) -r $(PROJECT_ROOT)/images/*.png $(INSTALL_ROOT_$(OS))/usr/share/demolauncher/assets/

include $(MKFILES_ROOT)/qtargets.mk
