/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include <string.h>
#include <errno.h>
#include "demolauncher.h"


bool
png_deinit(struct png_info * png_info) {
    if (png_info->rows != NULL) {
        png_free(png_info->png, png_info->rows);
    }

    if (png_info->file != NULL) {
        fclose(png_info->file);
    }

    png_destroy_read_struct(&png_info->png, &png_info->info, NULL);
    return true;
}

bool
png_init(struct png_info * png_info, char const * const path) {

    // Initialize the PNG reader
    png_info->png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (png_info->png == NULL) {
        fprintf(stderr, "Failed to create PNG structure\n");
        return false;
    }

    png_info->info = png_create_info_struct(png_info->png);
    if (png_info->info == NULL) {
        fprintf(stderr, "Failed to create PNG info structure\n");
        return false;
    }

    // Open the image file.
    png_info->file = fopen(path, "rb");
    if (png_info->file == NULL) {
        fprintf(stderr, "fopen(%s): %s\n", path, strerror(errno));
        return false;
    }

    // Check if this is a PNG image.
    unsigned char header[8];
    if (fread(header, 1, sizeof(header), png_info->file) < sizeof(header)) {
        fprintf(stderr, "File is not a PNG image\n");
        return false;
    }

    if (png_sig_cmp(header, 0, sizeof(header)) != 0) {
        fprintf(stderr, "File is not a PNG image\n");
        return false;
    }

    if (setjmp(png_jmpbuf(png_info->png))) {
        fprintf(stderr, "Failed to read PNG image\n");
        return false;
    }

    // Read image header.
    png_init_io(png_info->png, png_info->file);
    png_set_sig_bytes(png_info->png, sizeof(header));
    png_read_info(png_info->png, png_info->info);

    int depth;
    int colour;
    int interlace;
    png_get_IHDR(png_info->png, png_info->info, &png_info->width, &png_info->height, &depth,
                 &colour, &interlace, NULL, NULL);

    return true;
}

bool
png_load(struct png_info * png_info, screen_buffer_t const buf)
{
    // Prepare the window's buffer for copying.

    // Retrieve pointer to the buffer memory
    uint8_t *bufptr;
    if (screen_get_buffer_property_pv(buf, SCREEN_PROPERTY_POINTER, (void **)&bufptr)) {
        perror("screen_get_buffer_property_pv(SCREEN_PROPERTY_POINTER)");
        return false;
    }

    // Retrieve the stride (number of bytes per row in the buffer)
    int stride;
    if (screen_get_buffer_property_iv(buf, SCREEN_PROPERTY_STRIDE, &stride)) {
        perror("screen_get_buffer_property_iv(SCREEN_PROPERTY_STRIDE)");
        return false;
    }

    // Set up transforms.
    // Currently only RGB and RGBA formats are supported.
    // This will convert RGB888 to RGBA8888 format.
    png_set_bgr(png_info->png);
    int colour_type;
    colour_type = png_get_color_type(png_info->png, png_info->info);
    if (colour_type == PNG_COLOR_TYPE_RGB) {
        png_set_add_alpha(png_info->png, 0xffff, PNG_FILLER_AFTER);
    }


    // Set up row pointers for the PNG interpreter. 
    // Each row pointer matches the
    // Beginning of a row in the buffer.
    png_info->rows = png_malloc(png_info->png, png_info->height * sizeof(png_bytep));

    for (unsigned row = 0; row < png_info->height; row++) {
        png_info->rows[row] = (png_bytep)bufptr;
        bufptr += stride;
    }

    // Copy the image into the buffer.
    png_read_image(png_info->png, png_info->rows);
    return true;
}
