/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "demolauncher.h"

/**
 * Parse a .desktop file.
 * This is not a full parser for the XDG specification, but is sufficient to
 * extract the important key/value pairs.
 * @note    The strings assigned to the fields of the appicon structure are
 *          allocated with strdup(), and need to be freed if the structure is
 *          destroyed.
 * @param   name    The name of the file being parsed
 * @param   buf     File contents
 * @param   len     File length
 * @param   appicon The structure to populate
 */
static bool
parse(char const * const name, char * const buf, size_t const len, appicon_t * const appicon)
{
    appicon->name = NULL;
    appicon->execpath = NULL;
    appicon->imagepath = NULL;

    enum {
        FindKey,
        Key,
        Equals,
        FindValue,
        Value,
        Group,
        FindNewLine,
        Comment
    } state = FindKey;

    size_t pos = 0;
    char *start = NULL;
    char *key = NULL;
    char *value = NULL;

    for (;;) {
        // Check for end of data.
        if (pos == len) {
            break;
        }

        switch (state) {
        case FindKey:
            key = NULL;
            value = NULL;

            switch (buf[pos]) {
            case ' ':
            case '\t':
                // Ignore leading whitespace.
                break;

            case '[':
                state = Group;
                start = &buf[pos + 1];
                break;

            case '#':
                // Comment line.
                state = Comment;
                break;

            case '\n':
                // Empty line.
                break;

            default:
                state = Key;
                start = &buf[pos];
                break;
            }
            break;

        case Key:
            switch (buf[pos]) {
            case ' ':
            case '\t':
                key = start;
                buf[pos] = '\0';
                state = Equals;
                break;

            case '=':
                key = start;
                buf[pos] = '\0';
                state = FindValue;
                break;

            case '\n':
                // Key without a value.
                state = FindKey;
                break;

            case '#':
                // Key without a value.
                state = Comment;
                break;

            default:
                // Next key character.
                break;
            }
            break;

        case Equals:
            switch (buf[pos]) {
            case ' ':
            case '\t':
                // Ignore whitespace.
                break;

            case '=':
                state = FindValue;
                break;

            default:
                // Missing '=' after key.
                fprintf(stderr, "%s: parse error, no '=' after key\n", name);
                return false;
            }
            break;

        case FindValue:
            switch (buf[pos]) {
            case ' ':
            case '\t':
                // Ignore leading whitespace.
                break;

            case '\n':
                // Empty value followed by a new line.
                state = FindKey;
                break;

            case '#':
                // Empty value followed by a comment.
                state = Comment;
                break;

            case '=':
                fprintf(stderr, "%s: parse error, no '=' after key\n", name);
                return false;

            default:
                start = &buf[pos];
                state = Value;
                break;
            }
            break;

        case Value:
            switch (buf[pos]) {
            case '\n':
                buf[pos] = '\0';
                value = start;
                state = FindKey;
                break;

            case '#':
                buf[pos] = '\0';
                value = start;
                break;

            default:
                // Next value character.
                break;
            }
            break;

        case Group:
            switch (buf[pos]) {
            case ']':
                // New group.
                state = FindNewLine;
                break;

            case '\n':
            case '#':
                // Unterminated group.
                fprintf(stderr, "%s: parse error, no closing ']' for group\n",
                        name);
                return false;
            }
            break;

        case FindNewLine:
            switch (buf[pos]) {
            case ' ':
            case '\t':
                // Ignore whitespace.
                break;

            case '\n':
                state = FindKey;
                break;

            case '#':
                state = Comment;
                break;

            default:
                state = Value;
                break;
            }
            break;

        case Comment:
            if (buf[pos] == '\n') {
                state = FindKey;
            }
            break;
        }

        if ((key != NULL) && (value != NULL)) {
            // Found a key/value pair.
            if (strncmp(key, "Name", 4) == 0) {
                appicon->name = strdup(value);
            } else if (strncmp(key, "Icon", 4) == 0) {
                appicon->imagepath = strdup(value);
            } else if (strncmp(key, "Exec", 4) == 0) {
                appicon->execpath = strdup(strtok(value, " "));

                // Make sure first argument is the executable name
                // List MUST be terminated with a NULL
                appicon->num_args = 2;
                appicon->args = realloc(appicon->args, sizeof(char*) * appicon->num_args);
                appicon->args[0] = strdup(appicon->execpath);

                // Get the rest of the arguments for the executable
                const char *next_arg = strtok(NULL, " ");
                while (next_arg != NULL) {
                    appicon->num_args += 1;
                    appicon->args = realloc(appicon->args, sizeof(char*) * appicon->num_args);
                    appicon->args[appicon->num_args - 2] = strdup(next_arg);
                    next_arg = strtok(NULL, " ");
                }
                appicon->args[appicon->num_args - 1] = NULL;
            }

            key = NULL;
            value = NULL;
        }

        pos++;
    }

    if (appicon->name == NULL) {
        fprintf(stderr, "%s: parse error, missing Name\n", name);
        return false;
    }

    if (appicon->execpath == NULL) {
        fprintf(stderr, "%s: parse error, missing Exec\n", name);
        return false;
    }

    if (appicon->imagepath == NULL) {
        fprintf(stderr, "%s: parse error, missing Icon\n", name);
        return false;
    }

    return true;
}

/**
 * Read and parse a .desktop file
 * The function populates the imagepath and execpath of the given application
 * icon structure.
 * @param   dir_fd  Open directory file descriptor
 * @param   name    The file name
 * @param   appicon The structure to populate
 * @return  true if successful, false otherwise
 */
bool
desktop_entry_load(int const dir_fd, char const * const name, appicon_t * const appicon)
{
    // Open the file.
    int const fd = openat(dir_fd, name, O_RDONLY);
    if (fd == -1) {
        return false;
    }

    // Get file size.
    struct stat st;
    if (fstat(fd, &st) == -1) {
        close(fd);
        return false;
    }

    // Allocate a buffer for the file.
    // Desktop files are typically small 
    // (tens or hundreds of bytes).
    char * const buf = malloc(st.st_size);
    if (buf == NULL) {
        close(fd);
        return false;
    }

    // Read the file in its entirety.
    if (read(fd, buf, st.st_size) < st.st_size) {
        close(fd);
        return false;
    }

    close(fd);
    return parse(name, buf, st.st_size, appicon);
}
