#!/bin/bash
#deps
#sudo apk add freetype-dev qnx-io-sock-dev qnx-screen-dev

_exe_name=demolauncher
_install_dir="$DESTDIR/$PREFIX"
if [[ $1 == install ]]; then
    mkdir -p $_install_dir/bin
    mkdir -p $_install_dir/share/$_exe_name
    cp example.desktop $_install_dir/share/$_exe_name
    cp -r images $_install_dir/share/$_exe_name

    install -v -m755 $_exe_name $_install_dir/bin
    exit
fi


# Initial libraries
FT2_LIBS="$(pkgconf --libs freetype2)"
PNG_LIBS="$(pkgconf --libs libpng)"

# library flags
FT2_FLAGS="$(pkgconf --cflags freetype2)"
PNG_FLAGS="$(pkgconf --cflags libpng)"

CFLAGS="$CFLAGS $FT2_FLAGS $PNG_FLAGS"
LDFLAGS="$LDFLAGS -lscreen -lsocket $FT2_LIBS $PNG_LIBS"
SRC="$(ls | grep -e .c$ | xargs)"
echo "CFLAGS: $CFLAGS"
echo "LDFLAGS: $LDFLAGS"
echo "SRC: $SRC"

# make sure you set CC
echo "CC: $CFLAGS $SRC $LDFLAGS -o $_exe_name"
$CC $CFLAGS $SRC $LDFLAGS -o $_exe_name
