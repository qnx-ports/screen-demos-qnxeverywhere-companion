/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/keycodes.h>
#include "demolauncher.h"

#define DEFAULT_APP_PATH "/usr/share/demolauncher"
#define BACKGROUND_DEFAULT_BASE_NAME  DEFAULT_APP_PATH"/images/background"

int
main(int argc, char **argv) {
    // Parse command-line options provided by the user when launching the application.
    char const *app_path = DEFAULT_APP_PATH; // Default desktop files path
    char const *background = BACKGROUND_DEFAULT_BASE_NAME; // Default path to the background image with a subset of the background image name appended.
    char const *dpi_calc = "preset";

    // d : set dpi calculation (manual, screen, preset)
    for (;;) {
        int const opt = getopt(argc, argv, "a:b:d:");
        if (opt == 'a') {
            app_path = optarg; // Set the desktop files path if "-a" is provided.
        } else if (opt == 'b') {
            background = optarg; // Set the background image path if "-b" is provided.
        } else if (opt == 'd') {
            dpi_calc = optarg;
        } else if (opt == '?') {
            return 1;
        } else {
            break;
        }
    }

    // Populate appicon_t struct with desktop files content
    appicon_load_all(app_path);

    // Don't persist dead children in process table.
    struct sigaction sact = {
        .sa_flags = SA_NOCLDWAIT,
        .sa_sigaction = (void (*)(int,  struct _siginfo *, void *)) SIG_IGN
    };
    int err = sigaction(SIGCHLD, &sact, NULL);
    if (err != 0) {
        perror("sigaction(SIGCHLD)");
        return 1;
    }

    // Create a screen context.
    screen_context_t    context;
    if (screen_create_context(&context, SCREEN_APPLICATION_CONTEXT)) {
        perror("screen_create_context(SCREEN_APPLICATION_CONTEXT)");
        return 1;
    }

    // Variable to store screen window group
    char *window_group_name = calloc(WINDOW_GROUP_NAME_SIZE, 1);

    // Create the main window.
    screen_window_t window;
    if (!mainwindow_create(context, &window, background, window_group_name, dpi_calc)) {
        return 1;
    }

    /*
        This next block of code is used to inject an event to disable
        the window manager from closing this application.
    */

    // Create an event that can later be filled with event data
    screen_event_t win_manager_event;
    if (screen_create_event(&win_manager_event)) {
        perror("screen_create_event");
        return 1;
    }

    // Define the event type as SCREEN_EVENT_MANAGER
    int event_type = SCREEN_EVENT_MANAGER;
    if (screen_set_event_property_iv(win_manager_event, SCREEN_PROPERTY_TYPE, &event_type)) {
        perror("screen_set_event_property_iv(SCREEN_PROPERTY_TYPE)");
        return 1;
    }

    // Associate the event with the target window
    if (screen_set_event_property_pv(win_manager_event, SCREEN_PROPERTY_WINDOW, (void**)&window)) {
        perror("screen_set_event_property_pv(SCREEN_PROPERTY_WINDOW)");
        return 1;
    }

    // Retrieve the display associated with the current window
    screen_display_t current_disp;
    if (screen_get_window_property_pv(window, SCREEN_PROPERTY_DISPLAY, (void**)&current_disp)) {
        perror("screen_get_window_property_pv(SCREEN_PROPERTY_DISPLAY)");
        return 1;
    }

    // Define a message to indicate that the window cannot be closed
    // This message is specific to the window manager being used
    // Other window managers may require different messages
    char *manager_message = "can_close=false";

    if (screen_set_event_property_cv(win_manager_event, SCREEN_PROPERTY_USER_DATA, strlen(manager_message), manager_message)) {
        perror("screen_set_event_property_cv(SCREEN_PROPERTY_USER_DATA)");
        return 1;
    }

     // Inject the event into the display, effectively sending the event to the window manager
    if (screen_inject_event(current_disp, win_manager_event)) {
        perror("screen_inject_event");
        return 1;
    }

    // Ensure the screen context processes all pending commands immediately
    if (screen_flush_context(context, 0)) {
        perror("screen_flush_context");
        return 1;
    }

    /*
        This next block of code is used to listen to pointer,
        touch, and user events and process them accordingly
    */

    // Create a screen event to listen for input events
    screen_event_t  event;
    if (screen_create_event(&event) != 0) {
        perror("screen_create_event");
        return 1;
    }

    int app_launched_for_click = 0;

    // track previous timestamp and position to prevent unintended multiple
    // outputs for single input
    long long prev_timestamp = 0;
    int prev_position[2] = { 0, 0 };

    for (;;) {
        // Get the next event from the screen context.
        // -1 means the process will suspend until an event occurs.
        // A positive value sets the max wait time (in nanoseconds).
        if (screen_get_event(context, event, ~0L)) {
            perror("screen_get_event");
            return 1;
        }

        // Retrieve the type of the event (e.g., pointer, touch, etc.)
        int type;
        if (screen_get_event_property_iv(event, SCREEN_PROPERTY_TYPE, &type)) {
            perror("screen_get_event_property_iv(SCREEN_PROPERTY_TYPE)");
            return 1;
        }

        // Handle pointer events (mouse clicks or movements)
        if (type == SCREEN_EVENT_POINTER) {

            // Retrieve the button that is pressed
            int buttons;
            if (screen_get_event_property_iv(event, SCREEN_PROPERTY_BUTTONS, &buttons)) {
                perror("screen_get_event_property_iv(SCREEN_PROPERTY_BUTTONS)");
                return 1;
            }

            // Handle if the left mouse button is pressed
            if ((buttons & SCREEN_LEFT_MOUSE_BUTTON) != 0) {

                // Retrieve the position where the button is pressed
                int src_pos[2];
                if (screen_get_event_property_iv(event, SCREEN_PROPERTY_SOURCE_POSITION, src_pos)) {
                    perror("screen_get_event_property_iv(SCREEN_PROPERTY_SOURCE_POSITION)");
                    return 1;
                }

                // Spawn app clicked in their respective position
                if(!app_launched_for_click) {
                    appicon_clicked(src_pos);
                    app_launched_for_click = 1;
               }
            }
            else {
                app_launched_for_click = 0;
            }

        // Handle touch events
        } else if (type == SCREEN_EVENT_MTOUCH_TOUCH) {

            // Retrieve the position where the touch happens
            int pos[2];
            if (screen_get_event_property_iv(event, SCREEN_PROPERTY_SOURCE_POSITION, pos)) {
                perror("screen_get_event_property_iv(SCREEN_PROPERTY_SOURCE_POSITION)");
                return 1;
            }

            long long current_time;
            if (screen_get_event_property_llv(event, SCREEN_PROPERTY_TIMESTAMP, &current_time)) {
              perror("screen_get_event_property_llv(SCREEN_PROPERTY_TIMESTAMP)");
              return 1;
            }

            // Check if timestamp is within 150000 of first and if
            // same position as first. Skip this event if so, if not, set
            // prev_timestamp and prev_position.
            if (((current_time - prev_timestamp) < 150000) &&
                ((pos[0] == prev_position[0]) &&
                 (pos[1] == prev_position[1]))) {
              continue;
            }
            else {
              prev_timestamp = current_time;
              prev_position[0] = pos[0];
              prev_position[1] = pos[1];
            }

            // Launch a program if its respective button intersects the pointer (or touch) coordinates
            appicon_clicked(pos);
            app_launched_for_click = 1;

        // Handle keyboard events
        } else if (type == SCREEN_EVENT_KEYBOARD) {
            int flags;
            if (screen_get_event_property_iv(event, SCREEN_PROPERTY_FLAGS, &flags)) {
              perror("screen_get_event_property_iv(SCREEN_PROPERTY_FLAGS)");
              return 1;
            }
            // We only handle the initial key_down or key_repeat events
            if ((flags & (KEY_DOWN | KEY_REPEAT)) == 0) continue;

            int modifiers;
            if (screen_get_event_property_iv(event, SCREEN_PROPERTY_MODIFIERS, &modifiers)) {
              perror("screen_get_event_property_iv(SCREEN_PROPERTY_MODIFIERS)");
              return 1;
            }
            // Ignore events that have a modifier attached.
            // All the modifiers we care about are in the lower 16 bits
            if ((modifiers & 0xFFFF) != 0) continue;

            int cap;
            if (screen_get_event_property_iv(event, SCREEN_PROPERTY_KEY_CAP, &cap)) {
              perror("screen_get_event_property_iv(SCREEN_PROPERTY_KEY_CAP)");
              return 1;
            }
            switch (cap) {
                case KEYCODE_UP:
                    appicon_focus_move(context, 0, -1);
                    break;
                case KEYCODE_DOWN:
                    appicon_focus_move(context, 0, 1);
                    break;
                case KEYCODE_LEFT:
                    appicon_focus_move(context, -1, 0);
                    break;
                case KEYCODE_RIGHT:
                    appicon_focus_move(context, 1, 0);
                    break;
                case KEYCODE_RETURN:
                case KEYCODE_KP_ENTER:
                    appicon_focus_activate(context);
                    break;
            }

        // Handle custom user events
        } else if (type == SCREEN_EVENT_USER) {
            getIP();
            textbox.text = buf_ip;
            text_create(context, &textbox, window_group_name, dpi_calc);
        }
    }

    free(window_group_name);

    return 0;
}
