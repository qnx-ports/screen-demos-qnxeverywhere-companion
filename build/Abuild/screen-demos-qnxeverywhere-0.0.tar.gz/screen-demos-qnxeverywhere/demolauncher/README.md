# demolauncher

demolauncher is a QNX sample program demonstrating the Screen API for building graphical applications. It implements a simple application launcher with icons and text rendering.

## Project Structure

- `demolauncher.c`: Main application entry point, initializes screen context, and event handling
- `mainwindow.c`: Main window creation to display background image, icons, and text
- `apps.c`: Creates child window for displaying icons and setting their size and positioning
- `png.c`: Converts PNG data to screen buffer format used to display PNG images to the display
- `text.c`: Renders text using FreeType
- `ip.c`: Network interface monitoring
- `desktop_entry.c`: Parses desktop files

## Building Instructions

### Prerequisites

You need to have a local QNX SDP to build this project. To start, get a [QNX 8.0 license](https://www.qnx.com/products/everywhere/) and follow the offical instructions to install QNX 8.0 to your host machine.

### Minimum requirements on QSC
- com.qnx.qnx800.target/0.0.1.00135T202311191043L
- com.qnx.qnx800.host.linux.x86_64/0.0.1.00135T202311191043L
- com.qnx.qnx800.target.screen.fonts.engine/0.0.1.00020T202311191218L
- com.qnx.qnx800.target.screen.img_codecs/0.0.1.00102T202503082205L

### Building Steps

```bash
# Clone repo
git clone https://gitlab.com/qnx/projects/demolauncher.git && cd demolauncher

# Source the QNX environment
source <QNX-DIRECTORY>/qnxsdp-env.sh

# Build for aarch64
make
```

## Desktop Files

The launcher reads `.desktop` files to configure applications. Example format:

```ini
[Desktop Entry]
Name=Terminal
Exec=/system/bin/st
Icon=/system/etc/images/terminal.png
```
You can customize by modifying the following:
- Exec=/path/to/your/executables [args]
- Icon=/path/to/your/icon/images.png

Note: 
- The demolauncher code takes in 3 desktop files of the name 'left.desktop', 'middle.desktop', and 'right.desktop'
- You can create these 3 desktop files using the existing example.desktop and customize it to your needs
- You may also use the provided icon png's

## Deployment

1. Copy binary to target:
```bash
scp ./nto/aarch64/le/demolauncher qnxuser@<target_IP>:~/bin
```

2. Copy premade desktop files to the target:
```bash
scp <desktop-files> qnxuser@<target_IP>:~/
```

3. Copy background image and icons to the target:
```bash
scp -r images/ qnxuser@<target_IP>:~/
```

4. Launch:
```bash
# Example launch: ./demolauncher -a /data/home/qnxuser -b /data/home/qnxuser/images/background
./demolauncher -a <desktop-file-directory> -b <background-file-path>
```

Default paths:
- Desktop files: Current directory
- Background image: `/system/etc/images/background`
  > **Note:** The background path will be automatically concatenated with either "_1080p.png" or "_720p.png" based on the display resolution. For example:
  > - 1920x1080: `/system/etc/images/background_1080p.png`
  > - 1280x720: `/system/etc/images/background_720p.png`
  > - If resolution doesn't match either, defaults to 1080p version.
  > - If png files do not exist, background will default to blue color.

## Additional Resources

- [QNX Screen Developer's Guide](https://www.qnx.com/developers/docs/8.0/com.qnx.doc.screen/topic/manual/cscreen_about.html)

