/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include <stdlib.h>
#include <spawn.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include "demolauncher.h"

appicon_t      *apps;
unsigned        app_count = 0;

const int min_num_app_icons = 1;
const int max_num_app_icons = 10;

static size_t apps_size = max_num_app_icons * sizeof(appicon_t);

// FOCUS_COLOUR is an ARGB value
#define FOCUS_COLOUR 0x80FF443A
screen_window_t focus_win = NULL;
int focus_idx = -1;

#define SUFFIX      ".desktop"
#define SUFFIX_LEN  (sizeof(SUFFIX) - 1)

int select (const struct dirent *ent) {
    // Ignore entries with names shorter than the ".desktop" suffix.
    if (ent->d_namelen < SUFFIX_LEN) {
        return 0;
    }

    // Check if the file name ends with ".desktop".
    if (memcmp(&ent->d_name[ent->d_namelen - SUFFIX_LEN], SUFFIX, SUFFIX_LEN) != 0) {
        return 0;
    }

    return 1;
}
int
compare_appicon(const void *a1, const void *a2)
{
    appicon_t *appicon1 = (appicon_t *)a1;
    appicon_t *appicon2 = (appicon_t *)a2;
    return (strcmp(appicon1->name, appicon2->name));
}

static void free_dirent_list (struct dirent ***file_list, int length)
{
    if (*file_list == NULL) {
        return;
    }

    for (int i = 0; i < length; i++) {
        free((*file_list)[i]);
    }
    free(*file_list);
    *file_list = NULL;
}

void
appicon_load_all(char const * const path)
{
    // Allocate an initial array.
    apps = malloc(apps_size);
    if (apps == NULL) {
        return;
    }

    // Scan the directory for all *.deskop files
    struct dirent **file_list;
    int num_files_found = 0;

    num_files_found = scandir(path, &file_list, select, alphasort);
    if (num_files_found < 0) {
        perror("scandir(path, &file_list, select, alphasort))");
        return;
    }
    if (num_files_found == 0) {
        fprintf(stderr, "No desktop files found\n");
        return;
    }

    int const dir_fd = open(path, O_RDONLY | O_DIRECTORY);
    if (dir_fd == -1) {
        free_dirent_list(&file_list, num_files_found);
        return;
    }

    for (int i = 0; i < num_files_found; i++) {
        struct dirent * const ent = file_list[i];

        // Make sure the apps array is big enough.
        if (apps_size == (sizeof(appicon_t) * app_count)) {
            size_t const new_size = apps_size + 16 * sizeof(appicon_t);
            appicon_t * const new_apps = realloc(apps, apps_size);
            if (new_apps == NULL) {
                break;
            }

            apps = new_apps;
            apps_size = new_size;
        }

        // Read and parse the file and store information in the struct
        if (desktop_entry_load(dir_fd, ent->d_name, &apps[app_count])) {
            app_count++;

            if (app_count == max_num_app_icons) {
                break;
            }
        }
    }

    free_dirent_list(&file_list, num_files_found);
    close(dir_fd);

    if (app_count < min_num_app_icons) {
        printf("Did not receive minimum number of desktop files, expected %d entries\n", min_num_app_icons);
        exit(-1);
    }
    // Sort the list by app name.
    qsort(apps, app_count, sizeof(appicon_t), compare_appicon);
}

bool
appicon_create(screen_context_t const context, appicon_t * const app, char *window_group_name)
{
    // Create a child window
    screen_window_t window;
    if (screen_create_window_type(&window, context, SCREEN_CHILD_WINDOW)) {
        perror("screen_create_window_type(SCREEN_CHILD_WINDOW)");
        return false;
    }

    // Join the created window to a window group (using the provided window group name)
    if (screen_join_window_group(window, window_group_name)) {
        perror("screen_join_window_group");
        return false;
    }
    int usage = SCREEN_USAGE_READ | SCREEN_USAGE_WRITE | SCREEN_USAGE_NATIVE;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_USAGE, &usage)) {
      perror("screen_window_set_property_iv(SCREEN_PROPERTY_USAGE)");
      return false;
    }

    // Set window size and position
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_POSITION, &app->rect[0])) {
        perror("screen_window_set_property_iv(SCREEN_PROPERTY_POSITION)");
        return false;
    }

    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_SIZE, &app->rect[2])) {
        perror("screen_window_set_property_iv(SCREEN_PROPERTY_SIZE)");
        return false;
    }

    // Set the window's buffer format to RGBA8888
    int format = SCREEN_FORMAT_RGBA8888;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_FORMAT, &format)) {
        perror("screen_set_buffer_property_iv(SCREEN_PROPERTY_FORMAT)");
        return false;
    }

    // Set the visibility of the window to visible. Although by default it is set to be visible.
    int visible = 1;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_VISIBLE, &visible)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
        return false;
    }

    // Set screen sensitivity mask of this window to never.
    // Preventing it from receiving pointer or multi-touch events.
    // (Only the parent window should process these events).
    // Also disable this window from acquiring input focus.
    // Ensuring the parent window retains focus even when raised.
    int sensitivity = SCREEN_SENSITIVITY_NEVER;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_SENSITIVITY, &sensitivity)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_SENSITIVITY)");
        return false;
    }

    // Initialize the PNG information from the image file path.
    if(!png_init(&app->png_info, app->imagepath)) {
        return false;
    }

    // Set the buffer size of the window to match the dimensions of the PNG image.
    int buffer_size[2] = { app->png_info.width, app->png_info.height};
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_BUFFER_SIZE, buffer_size)) {
        perror("screen_window_set_property_iv(buffer SCREEN_PROPERTY_BUFFER_SIZE)");
        return false;
    }

    // Create the window buffers for displaying the icons
    if (screen_create_window_buffers(window, 1)) {
        perror("screen_create_window_buffers");
        return false;
    }

    // Retrieve the window buffer.
    screen_buffer_t buf;
    if (screen_get_window_property_pv(window, SCREEN_PROPERTY_BUFFERS, (void **)&buf)) {
        perror("screen_get_window_property_pv(SCREEN_PROPERTY_BUFFERS)");
        return false;
    }

    // Load the PNG image into the window buffer.
    if (!png_load(&app->png_info, buf)) {
        return false;
    }

    // Post the window to make the changes done to the window visible
    if (screen_post_window(window, buf, 1, app->rect, 0)) {
        perror("screen_post_window");
        return false;
    }

    app->window = window;
    return true;
}

static void launch_app(appicon_t *app) {
    pid_t pid;
    int rc = posix_spawn(&pid, app->execpath, NULL, NULL, app->args, NULL);
    if (rc != 0) {
        fprintf(stderr, "Failed to launch %s: %s\n", app->execpath, strerror(rc));
    }
}

void
appicon_clicked(int pos[2])
{
    // Search for a matching app icon.
    for (unsigned i = 0; i < app_count; i++) {
        if ((pos[0] >= apps[i].rect[0]) &&
            (pos[0] < apps[i].rect[0] + apps[i].rect[2]) &&
            (pos[1] >= apps[i].rect[1]) &&
            (pos[1] < apps[i].rect[1] + apps[i].rect[3])) {
            launch_app(&apps[i]);
            break;
        }
    }
}

bool appicon_focus_create(screen_context_t context, int width, int height, char *window_group_name) {
    // Create a child window
    screen_window_t window;
    if (screen_create_window_type(&window, context, SCREEN_CHILD_WINDOW)) {
        perror("screen_create_window_type(SCREEN_CHILD_WINDOW)");
        return false;
    }

    // Join the created window to a window group (using the provided window group name)
    if (screen_join_window_group(window, window_group_name)) {
        perror("screen_join_window_group");
        return false;
    }
    int usage = SCREEN_USAGE_READ | SCREEN_USAGE_WRITE | SCREEN_USAGE_NATIVE;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_USAGE, &usage)) {
      perror("screen_window_set_property_iv(SCREEN_PROPERTY_USAGE)");
      return false;
    }

    // We want the focus window to be above the application windows in the same
    // group. So get the current value, whatever it is, and increase it by 1
    int zorder;
    if (screen_get_window_property_iv(window, SCREEN_PROPERTY_ZORDER, &zorder)) {
        perror("screen_get_window_property_iv(SCREEN_PROPERTY_ZORDER)");
        return false;
    }
    zorder++;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_ZORDER, &zorder)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_ZORDER)");
        return false;
    }

    // Set window dimensions
    int dims[2] = {width, height};
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_SIZE, dims)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
        return false;
    }

    // Set the window's buffer format to RGBA8888
    int format = SCREEN_FORMAT_RGBA8888;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_FORMAT, &format)) {
        perror("screen_set_buffer_property_iv(SCREEN_PROPERTY_FORMAT)");
        return false;
    }

    // Set the visibility of the window to invisible. By default, focus is not shown
    int visible = 0;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_VISIBLE, &visible)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
        return false;
    }

    // Set screen sensitivity mask of this window to never.
    // Preventing it from receiving pointer or multi-touch events.
    // (Only the parent window should process these events).
    // Also disable this window from acquiring input focus.
    // Ensuring the parent window retains focus even when raised.
    int sensitivity = SCREEN_SENSITIVITY_NEVER;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_SENSITIVITY, &sensitivity)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_SENSITIVITY)");
        return false;
    }

    // Create the underlying buffer
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_BUFFER_SIZE, dims)) {
        perror("screen_window_set_property_iv(buffer SCREEN_PROPERTY_BUFFER_SIZE)");
        return false;
    }
    if (screen_create_window_buffers(window, 1)) {
        perror("screen_create_window_buffers");
        return false;
    }

    // Render the focus colour to that buffer
    screen_buffer_t buf;
    if (screen_get_window_property_pv(window, SCREEN_PROPERTY_BUFFERS, (void **)&buf)) {
        perror("screen_get_window_property_pv(SCREEN_PROPERTY_BUFFERS)");
        return false;
    }
    int attribs[] = {
        SCREEN_BLIT_COLOR, FOCUS_COLOUR,
        SCREEN_BLIT_END
    };
    if (screen_fill(context, buf, attribs)) {
        perror("screen_fill");
        return false;
    }

    // Post the window so that it can be made visible later when required.
    // This does an implicit flush of the blit above.
    if (screen_post_window(window, buf, 0, NULL, 0)) {
        perror("screen_post_window");
        return false;
    }

    focus_win = window;
    return true;
}


static void focus_set_index(screen_context_t context, int idx) {
    if (idx != focus_idx) {
        int dims[2] = {apps[idx].rect[0], apps[idx].rect[1]};
        if (screen_set_window_property_iv(focus_win, SCREEN_PROPERTY_POSITION, dims)) {
            perror("screen_window_set_property_iv(SCREEN_PROPERTY_POSITION)");
            return;
        }

        if (focus_idx == -1) {
            // Focus should now be visible
            int visible = 1;
            if (screen_set_window_property_iv(focus_win, SCREEN_PROPERTY_VISIBLE, &visible)) {
                perror("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
                return;
            }
        }
        focus_idx = idx;

        screen_flush_context(context, 0);
    }
}


void appicon_focus_move(screen_context_t context, int x, int y) {
    int new_idx = -1;

    if (focus_idx == -1) {
        // Regardless of the delta, just enable the focus on the center icon
        new_idx = app_count / 2;
    } else {
        // We don't do anything with y at the moment
        (void)y;
        new_idx = focus_idx + x;
        while (new_idx < 0) new_idx += app_count;
        while (new_idx >= app_count) new_idx -= app_count;
    }
    focus_set_index(context, new_idx);
}

void appicon_focus_activate(screen_context_t context) {
    if (focus_idx == -1) {
        // Focus is not currently being shown. Show it on
        // the middle icon and then trigger it.
        focus_set_index(context, app_count / 2);
    }
    launch_app(&apps[focus_idx]);
}
