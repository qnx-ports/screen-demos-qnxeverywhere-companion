/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#ifndef DEMOLAUNCHER_H
#define DEMOLAUNCHER_H

#include <stdbool.h>
#include <screen/screen.h>
#include <errno.h>
#include <png.h>

#define WINDOW_GROUP_NAME_SIZE 1024

struct png_info {
    png_structp png;
    png_infop info;
    FILE *file;
    png_bytep *rows;
    unsigned width;
    unsigned height;
};

typedef struct {
    char const      *name;
    char const      *imagepath;
    char const      *execpath;
    char            **args;
    int             num_args;
    int             rect[4];
    screen_window_t window;
    struct png_info png_info;
} appicon_t;

typedef struct
{
    char const     *text;
    char const     *font_path;
    int             rect[4];
    int             ptsize[2];
    screen_window_t window;
    screen_window_t mainwindow;
} textbox_t;


bool mainwindow_create(screen_context_t context, screen_window_t *windowp,
                       char const *background, char *window_group_name,
                       char const *dpi_calc);
bool png_init(struct png_info * png_info, char const * const path);
bool png_deinit(struct png_info * png_info);
bool png_load(struct png_info * png_info, screen_buffer_t buf);

void appicon_load_all(char const *path);
bool appicon_create(screen_context_t context, appicon_t *app, char *window_group_name);
void appicon_clicked(int pos[2]);

bool appicon_focus_create(screen_context_t context, int width, int height, char *window_group_name);
void appicon_focus_move(screen_context_t context, int x, int y);
void appicon_focus_activate(screen_context_t context);

bool desktop_entry_load(int dir_fd, char const *name, appicon_t *app);

bool text_create(screen_context_t context, textbox_t * tbox_t,
                 char *window_group_name, char const *dpi_calc);

void* monitor_ipc_changes(void* data);
void initialize_ipc_monitor(screen_context_t context);
void getIP();

extern appicon_t   *apps;
extern unsigned     app_count;

extern int routeSocket_;
extern int ifIndex_;
extern struct in_addr addr_;
extern char buf_ip[20];
extern textbox_t textbox;

#endif
