/*
 * $QNXLicenseC:
 * Copyright 2024, QNX Software Systems Limited. All Rights Reserved.
 *
 * This software is QNX Confidential Information subject to
 * confidentiality restrictions. DISCLOSURE OF THIS SOFTWARE
 * IS PROHIBITED UNLESS AUTHORIZED BY QNX SOFTWARE SYSTEMS IN
 * WRITING.
 *
 * You must obtain a written license from and pay applicable license
 * fees to QNX Software Systems Limited before you may reproduce, modify
 * or distribute this software, or any work that includes all or part
 * of this software. For more information visit
 * http://licensing.qnx.com or email licensing@qnx.com.
 *
 * This file may contain contributions from others.  Please review
 * this entire file for other proprietary rights or license notices,
 * as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <screen/screen.h>
#include <sys/keycodes.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include "demolauncher.h"

// Set DPI so 13pt font matches background image text size
#define DPI_1080p 144
#define DPI_720p 96

// Scale text based on display DPI as calculated by screen
bool display_dpi(screen_window_t window, int *dpi) {
  // Retrieve the display associated with the window.
  screen_display_t current_disp;
  if (screen_get_window_property_pv(window, SCREEN_PROPERTY_DISPLAY, (void**)&current_disp)) {
    perror("screen_get_window_property_pv(SCREEN_PROPERTY_DISPLAY)");
    return false;
  }
  if(screen_get_display_property_iv(current_disp, SCREEN_PROPERTY_DPI, dpi)) {
    perror("screen_get_window_property_iv(SCREEN_PROPERTY_DPI)");
    return false;
  }
  return true;
}

// Scale text based on display DPI calculated manually
bool self_calculated_dpi(screen_window_t window, int *dpi, int *mainwindow_buffersize) {
    // Retrieve the display associated with the window.
    screen_display_t current_disp;
    if (screen_get_window_property_pv(window, SCREEN_PROPERTY_DISPLAY, (void**)&current_disp)) {
        perror("screen_get_window_property_pv(SCREEN_PROPERTY_DISPLAY)");
        return 1;
    }
    int physical_size[2] = {0, 0};
    if (screen_get_display_property_iv(current_disp, SCREEN_PROPERTY_PHYSICAL_SIZE, physical_size)) {
        perror("screen_get_display_property_iv(SCREEN_PROPERTY_PHYSICAL_SIZE)");
        return 1;
    }

    #define MILLIMETERS_PER_INCH 25.4001f
    dpi[0] = (int)(mainwindow_buffersize[0] * MILLIMETERS_PER_INCH / physical_size[0] + 0.5f);
    dpi[1] = (int)(mainwindow_buffersize[1] * MILLIMETERS_PER_INCH / physical_size[1] + 0.5f);

    return true;
}

// Scale text based on DPI presets
bool preset_dpi(screen_window_t window, int *dpi, int *mainwindow_buffersize) {
  // Set text DPI manually since, want the text DPI set so 13pt matches image font size
  if (mainwindow_buffersize[1] == 1080) {
    dpi[0] = DPI_1080p;
  }
  else if (mainwindow_buffersize[1] == 720) {
    dpi[0] = DPI_720p;

  } else {
    fprintf(stderr, "Failed set screen buffer size correctly.\n");
    fprintf(stderr, "Received buffer size: %d, %d\n", mainwindow_buffersize[0], mainwindow_buffersize[1]);
    fprintf(stderr, "Expecting either (1280, 720) or (1920, 1080)\n");
    return false;
  }
  dpi[1] = dpi[0];
  return true;
}

void
draw_glyph_to_screen(screen_buffer_t screen_buf, FT_GlyphSlot glyph, int x, int y) {
    int glyph_width = glyph->bitmap.width;
    int glyph_height = glyph->bitmap.rows;

    // Retrieve the buffer size
    int bufsize;
    if (screen_get_buffer_property_iv(screen_buf, SCREEN_PROPERTY_SIZE, &bufsize)) {
        perror("screen_get_buffer_property_iv(SCREEN_PROPERTY_SIZE)");
        return;
    }

    // Retrieve the stride (number of bytes per row in the buffer)
    int stride;
    if (screen_get_buffer_property_iv(screen_buf, SCREEN_PROPERTY_STRIDE, &stride)) {
        perror("screen_get_buffer_property_iv(SCREEN_PROPERTY_STRIDE)");
        return;
    }

    // Retrieve pointer to the buffer memory
    uint32_t *bufptr;
    if (screen_get_buffer_property_pv(screen_buf, SCREEN_PROPERTY_POINTER, (void **)&bufptr)) {
        perror("screen_get_buffer_property_pv(SCREEN_PROPERTY_POINTER)");
        return;
    }

    int adjusted_y = y - glyph -> bitmap_top;

    for (int row = 0; row < glyph_height; row++) {
        int screen_y = adjusted_y + row;  // Top-left corner is y
        for (int col = 0; col < glyph_width; col++) {
            int screen_x = x + col;

            unsigned char pixel_intensity = *(glyph->bitmap.buffer + row * glyph->bitmap.pitch + col);
            // Set pixel in the screen buffer
            // Ensure pixel is within bounds
            if (screen_x < 0 || screen_y < 0) continue;

            int offset = (screen_y * stride / sizeof(uint32_t)) + screen_x;
            if (offset >= bufsize) {
                continue;
            }

            // Calculate buffer position based on stride
            uint32_t* pixel_ptr = bufptr + (screen_y * stride / sizeof(uint32_t)) + screen_x;

            // Convert grayscale to RGBX8888 (R=G=B=pixel_intensity)
            uint32_t rgbx_pixel = (pixel_intensity << 24)| (pixel_intensity << 16) | (pixel_intensity << 8) | (pixel_intensity); // RGBX8888

            // Set the pixel in the buffer
            *pixel_ptr = rgbx_pixel;
        }
    }
}

void
render_text(screen_buffer_t screen_buf, int font_size, const char* font_path, const char *text, int buf_width, int buf_height, int* dpis) {

    const char* p;

    // Retrieve the buffer size
    int bufsize;
    if (screen_get_buffer_property_iv(screen_buf, SCREEN_PROPERTY_SIZE, &bufsize)) {
        perror("screen_get_buffer_property_iv(SCREEN_PROPERTY_SIZE)");
        return;
    }

    // Retrieve pointer to the buffer memory
    uint32_t *bufptr;
    if (screen_get_buffer_property_pv(screen_buf, SCREEN_PROPERTY_POINTER, (void **)&bufptr)) {
        perror("screen_get_buffer_property_pv(SCREEN_PROPERTY_POINTER)");
        return;
    }

    // Clear the entire buffer (set all pixels to black)
    memset(bufptr, 0x00000000, bufsize);

    #if 0 //DEBUG to print tbox border.
    memset(bufptr, 0xFFFFFFFF, buf_width);
    memset(bufptr + buf_width * 1, 0xFFFFFFFF, buf_width);
    memset(bufptr + buf_width * 2, 0xFFFFFFFF, buf_width);
    memset(bufptr + buf_width * (buf_height - 1), 0xFFFFFFFF, buf_width);
    memset(bufptr + buf_width * (buf_height - 2), 0xFFFFFFFF, buf_width);
    #endif

    // Initialize FreeType library for font rendering
    FT_Library ft_library;
    FT_Face face;

    if (FT_Init_FreeType(&ft_library)) {
        perror("Could not initialize FreeType library\n");
        return;
    }

    if (FT_New_Face(ft_library, font_path, 0, &face)) {
        fprintf(stderr, "Could not load font %s\n", font_path);
        FT_Done_FreeType(ft_library);
        return;
    }

    // Set the character size based off of the font size and the DPI
    int ft_error = FT_Set_Char_Size(face, 0, font_size * 64, dpis[0], dpis[1]);
    if (ft_error) {
        fprintf(stderr, "Could not set char size to %d pt. Error: %d.", font_size, ft_error);
        FT_Done_FreeType(ft_library);
        return;
    }

    // Calculate the offset for the first line so baseline is bottom aligned.
    int first_line_max_top = 0;
    for (p = text; *p; p++) {
        // We only need to shift the first line to prevent buffer underflow
        if (*p == '\n') {
            break;
        }
        if (FT_Load_Char(face, *p, FT_LOAD_RENDER)) {
            perror("Could not load character\n");
            continue;
        }

        first_line_max_top = face->glyph->bitmap_top > first_line_max_top ? face->glyph->bitmap_top : first_line_max_top;
    }

    int x = 0;
    int y = first_line_max_top;
    for (p = text; *p; p++) {
        if (*p == '\n') {
            x = 0;
            y += face->size->metrics.height >> 6;
            continue;
        }
        if (FT_Load_Char(face, *p, FT_LOAD_RENDER)) {
            perror("Could not load character\n");
            continue;
        }

        draw_glyph_to_screen(screen_buf, face->glyph, x, y);

        // Move the x position based on glyph advance
        x += face->glyph->advance.x >> 6;
    }

    // Cleanup
    FT_Done_Face(face);
    FT_Done_FreeType(ft_library);
}

bool
text_create(screen_context_t const context, textbox_t * tbox_t, char *window_group_name,
            char const *dpi_calc)
{
    int font_size = tbox_t->ptsize[1];
    const int* rect = tbox_t->rect;
    const char* font_path = tbox_t->font_path;
    const char* text = tbox_t->text;

    bool create_win_buf = false;

    // Create a child window.
    screen_window_t window;

    // Check if a window already exists for this text box.
    if (tbox_t->window != NULL) {
        window = tbox_t->window;
    } else {
        // Create a new child window if one does not exist.
        if (screen_create_window_type(&window, context, SCREEN_CHILD_WINDOW) != 0) {
            perror("screen_create_window_type(SCREEN_CHILD_WINDOW)");
            return false;
        }
        tbox_t->window = window;

        // Join the created window to a window group (using the provided window group name).
        if (screen_join_window_group(window, window_group_name) != 0) {
            perror("screen_join_window_group");
            return false;
        }
        create_win_buf = true;
    }

    // Retrieve the buffer size of the main window (in pixels) to check resolution.
    int mainwindow_buffersize[2] = { 0,0 };
    if(screen_get_window_property_iv(tbox_t->mainwindow, SCREEN_PROPERTY_BUFFER_SIZE, mainwindow_buffersize)) {
        perror("screen_get_window_property_iv(SCREEN_PROPERTY_BUFFER_SIZE)");
        return false;
    }
    int dpi[2] = {0, 0};
    if (strcmp(dpi_calc, "screen") == 0) {
      display_dpi(window, dpi);
    } else if (strcmp(dpi_calc, "manual") == 0) {
      self_calculated_dpi(window, dpi, mainwindow_buffersize);
    } else if (strcmp(dpi_calc, "preset") == 0) {
      preset_dpi(window, dpi, mainwindow_buffersize);
    } else {
      preset_dpi(window, dpi, mainwindow_buffersize);
    }

    // Set window size and position.based on the calculations
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_POSITION, rect)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_POSITION)");
        return false;
    }

    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_SIZE, rect + 2)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_SIZE)");
        return false;
    }

    // Set the window's buffer format to RGBA8888
    int format = SCREEN_FORMAT_RGBA8888;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_FORMAT, &format)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_FORMAT)");
        return false;
    }

    // Set the visibility of the window to visible. Although by default it is set to be visible.
    int visible = 1;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_VISIBLE, &visible)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_VISIBLE)");
        return false;
    }

    // Set screen sensitivity mask of this window to never.
    // Preventing it from receiving pointer or multi-touch events.
    // (Only the parent window should process these events).
    // Also disable this window from acquiring input focus.
    // Ensuring the parent window retains focus even when raised.
    int sensitivity = SCREEN_SENSITIVITY_NEVER;
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_SENSITIVITY, &sensitivity)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_SENSITIVITY)");
        return false;
    }

    // Set the buffer size for textbox
    int buffer_size[2] = { rect[2], rect[3]};
    if (screen_set_window_property_iv(window, SCREEN_PROPERTY_BUFFER_SIZE, buffer_size)) {
        perror("screen_set_window_property_iv(SCREEN_PROPERTY_BUFFER_SIZE size)");
        return false;
    }

    if (create_win_buf) {
      if (screen_create_window_buffers(window, 1) != 0) {
        perror("screen_create_window_buffers");
        return false;
      }
      create_win_buf = false;
    }

    // Retrieve the window buffer.
    screen_buffer_t buf;
    if (screen_get_window_property_pv(window, SCREEN_PROPERTY_BUFFERS, (void **)&buf)) {
        perror("screen_get_window_property_pv(SCREEN_PROPERTY_BUFFERS)");
        return false;
    }

    render_text(buf, font_size, font_path, text, rect[2], rect[3], dpi);

    // Post the window to make the changes done to the window visible
    if (screen_post_window(window, buf, 0, NULL, 0)) {
        perror("screen_post_window");
        return false;
    }

    return true;
}
